import bundledTemplateEditorRuntime from "./template-editor-runtime.bundle.js";
import {
  prepareTemplatePageHtml,
  syncTemplatePageSettingsFromHtml,
} from "../core/template-page-settings.js";
import {
  getDocumentOverflowMessage,
  getDocumentSurfaceOverflowInfo,
  sanitizeTemplateEditorHtml,
} from "../dom/index.js";

let mountedInstanceCounter = 0;

function isObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function escapeHtmlAttribute(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => {
    switch (character) {
      case "&":
        return "&amp;";
      case "<":
        return "&lt;";
      case ">":
        return "&gt;";
      case '"':
        return "&quot;";
      case "'":
        return "&#39;";
      default:
        return character;
    }
  });
}

function getFirstNonEmptyString(...values) {
  for (const value of values) {
    const text = String(value ?? "").trim();

    if (text) {
      return text;
    }
  }

  return "";
}

function normalizeImageDimension(value) {
  const numberValue = Number(value);

  if (!Number.isFinite(numberValue) || numberValue <= 0) {
    return null;
  }

  return Math.round(numberValue);
}

function getUploadedImageSource(uploadResult, runtimeOptions) {
  if (typeof uploadResult === "string") {
    return uploadResult.trim();
  }

  if (!isObject(uploadResult)) {
    return "";
  }

  const directSource = getFirstNonEmptyString(
    uploadResult.url,
    uploadResult.src,
    uploadResult.href,
    uploadResult.source,
  );

  if (directSource) {
    return directSource;
  }

  const pathSource = getFirstNonEmptyString(uploadResult.path, uploadResult.filePath, uploadResult.key);

  if (!pathSource) {
    return "";
  }

  const resolvedSource =
    typeof runtimeOptions.buildApiUrl === "function" ? String(runtimeOptions.buildApiUrl(pathSource) || "").trim() : "";

  return resolvedSource || pathSource;
}

function buildUploadedImageMarkup(uploadResult, file, runtimeOptions) {
  const source = getUploadedImageSource(uploadResult, runtimeOptions);

  if (!source) {
    return "";
  }

  const caption =
    typeof uploadResult === "string"
      ? getFirstNonEmptyString(file?.name, "image")
      : getFirstNonEmptyString(uploadResult.alt, uploadResult.caption, uploadResult.title, uploadResult.name, file?.name, "image");
  const width = isObject(uploadResult) ? normalizeImageDimension(uploadResult.width) : null;
  const height = isObject(uploadResult) ? normalizeImageDimension(uploadResult.height) : null;
  const sizeAttributes = [
    width ? ` width="${width}"` : "",
    height ? ` height="${height}"` : "",
  ].join("");

  return `<img src="${escapeHtmlAttribute(source)}" alt="${escapeHtmlAttribute(caption)}" title="${escapeHtmlAttribute(caption)}"${sizeAttributes} />`;
}

function cloneTemplateValue(value) {
  if (!isObject(value)) {
    return value;
  }

  if (typeof structuredClone === "function") {
    return structuredClone(value);
  }

  return JSON.parse(JSON.stringify(value));
}

function normalizeDataTags(dataTags) {
  if (Array.isArray(dataTags)) {
    return dataTags;
  }

  if (Array.isArray(dataTags?.tags)) {
    return dataTags.tags;
  }

  if (Array.isArray(dataTags?.definitions)) {
    return dataTags.definitions;
  }

  if (Array.isArray(dataTags?.groups)) {
    return dataTags.groups.flatMap((group) => (Array.isArray(group?.tags) ? group.tags : []));
  }

  return [];
}

function getTemplatePages(template) {
  return Array.isArray(template?.layout?.pages) ? template.layout.pages : [];
}

function getTemplatePage(template, pageId = "") {
  const pages = getTemplatePages(template);

  if (pages.length === 0) {
    return null;
  }

  const normalizedPageId = String(pageId || "").trim();

  return (normalizedPageId ? pages.find((page) => String(page?.id || "") === normalizedPageId) : null) || pages[0];
}

function resolveTemplatePageId(template, pageId = "") {
  const normalizedPageId = String(pageId || "").trim();
  const selectedPage = getTemplatePage(template, normalizedPageId);

  return String(selectedPage?.id || normalizedPageId).trim();
}

function getTemplateDocumentHtml(template, pageId = "") {
  if (typeof template === "string") {
    return template;
  }

  if (!isObject(template)) {
    return "";
  }

  const selectedPage = getTemplatePage(template, pageId);
  const pageHtml = selectedPage?.settings?.documentHtml;

  if (typeof pageHtml === "string") {
    return pageHtml;
  }

  if (typeof template.documentHtml === "string") {
    return template.documentHtml;
  }

  if (typeof template.html === "string") {
    return template.html;
  }

  if (typeof template.settings?.documentHtml === "string") {
    return template.settings.documentHtml;
  }

  return "";
}

function prepareTemplateDocumentHtml(template, html, pageId = "") {
  if (!getTemplatePage(template, pageId)) {
    return String(html || "");
  }

  return prepareTemplatePageHtml(template, pageId, html);
}

function sanitizeResolvedHtml(html, documentRef, options = {}) {
  if (options.sanitizeHtml === false) {
    return String(html || "");
  }

  return sanitizeTemplateEditorHtml(html, documentRef);
}

function sanitizeTemplateValue(value, documentRef, options = {}) {
  if (typeof value === "string") {
    return sanitizeResolvedHtml(value, documentRef, options);
  }

  if (!isObject(value)) {
    return value;
  }

  const nextValue = cloneTemplateValue(value);

  getTemplatePages(nextValue).forEach((page) => {
    if (typeof page?.settings?.documentHtml === "string") {
      page.settings.documentHtml = sanitizeResolvedHtml(page.settings.documentHtml, documentRef, options);
    }
  });

  if (typeof nextValue.documentHtml === "string") {
    nextValue.documentHtml = sanitizeResolvedHtml(nextValue.documentHtml, documentRef, options);
  }

  if (typeof nextValue.html === "string") {
    nextValue.html = sanitizeResolvedHtml(nextValue.html, documentRef, options);
  }

  if (typeof nextValue.settings?.documentHtml === "string") {
    nextValue.settings.documentHtml = sanitizeResolvedHtml(nextValue.settings.documentHtml, documentRef, options);
  }

  return nextValue;
}

function getTemplatePageKey(template, page, index) {
  const pageId = String(page?.id || "").trim();

  return `page:${index}:${pageId}`;
}

function getSelectedTemplatePageKey(template, pageId = "") {
  const pages = getTemplatePages(template);

  if (pages.length === 0) {
    return "value";
  }

  const selectedPage = getTemplatePage(template, pageId);
  const selectedPageIndex = Math.max(0, pages.indexOf(selectedPage));

  return getTemplatePageKey(template, selectedPage, selectedPageIndex);
}

function prepareSpecificTemplatePageHtml(template, page, html) {
  if (!page || !isObject(template)) {
    return String(html || "");
  }

  const scopedTemplate = {
    ...template,
    layout: {
      ...(isObject(template.layout) ? template.layout : {}),
      pages: [page],
    },
  };

  return prepareTemplatePageHtml(scopedTemplate, page.id, html);
}

function createTemplateHtmlSnapshot(template, documentRef, options = {}) {
  const pages = getTemplatePages(template);

  if (pages.length === 0) {
    return JSON.stringify([
      {
        html: sanitizeResolvedHtml(getTemplateDocumentHtml(template), documentRef, options),
        key: "value",
      },
    ]);
  }

  return JSON.stringify(
    pages.map((page, index) => ({
      html: sanitizeResolvedHtml(
        prepareSpecificTemplatePageHtml(template, page, page?.settings?.documentHtml),
        documentRef,
        options,
      ),
      key: getTemplatePageKey(template, page, index),
    })),
  );
}

function setTemplateDocumentHtml(template, html, pageId = "", initialPaperPreset = "") {
  if (typeof template === "string" || !isObject(template)) {
    return String(html || "");
  }

  const nextTemplate = cloneTemplateValue(template);
  const selectedPage = getTemplatePage(nextTemplate, pageId);

  if (selectedPage) {
    syncTemplatePageSettingsFromHtml(nextTemplate, pageId, html, initialPaperPreset);
    return nextTemplate;
  }

  if (isObject(nextTemplate.settings)) {
    nextTemplate.settings.documentHtml = String(html || "");
    return nextTemplate;
  }

  nextTemplate.documentHtml = String(html || "");
  return nextTemplate;
}

function resolveInitialHtml(options) {
  let initialHtml = "";

  if (typeof options.html === "string") {
    initialHtml = options.html;
  } else if (typeof options.initialHtml === "string") {
    initialHtml = options.initialHtml;
  } else {
    initialHtml = getTemplateDocumentHtml(options.template, options.selectedPageId);
  }

  const preparedHtml = prepareTemplateDocumentHtml(options.template, initialHtml, options.selectedPageId);

  return sanitizeResolvedHtml(preparedHtml, options.document || globalThis.document, options);
}

function resolveRootElement(root, documentRef) {
  if (typeof root === "string") {
    return documentRef.querySelector(root);
  }

  return root?.nodeType === 1 ? root : null;
}

function assertBrowserDocument(documentRef) {
  if (!documentRef?.createElement) {
    throw new Error("mountTemplateEditor() requires a browser Document. Use core APIs in non-browser environments.");
  }
}

function setDirtyState(state, nextDirty, callback) {
  if (state.isDirty === nextDirty) {
    return;
  }

  state.isDirty = nextDirty;
  callback?.(nextDirty);
}

function applyReadOnlyMode(rootElement, isReadOnly) {
  rootElement.classList.toggle("is-read-only", isReadOnly);
  rootElement.dataset.examlistTemplateEditorReadonly = isReadOnly ? "true" : "false";

  const surfaceElement = rootElement.querySelector("[data-template-editor-runtime-surface]");
  surfaceElement?.setAttribute("contenteditable", isReadOnly ? "false" : "true");
  surfaceElement?.setAttribute("aria-readonly", isReadOnly ? "true" : "false");

  rootElement.querySelectorAll("button, input, select, textarea").forEach((controlElement) => {
    controlElement.disabled = isReadOnly;
    controlElement.setAttribute("aria-disabled", isReadOnly ? "true" : "false");
  });
}

function removeTransientRuntimeNodes(rootElement) {
  rootElement
    .querySelectorAll(
      [
        ".template-editor-image-selection",
        ".template-editor-table-selection",
        "[data-template-double-border-overlay]",
        "[data-template-table-object-move-handle]",
        "[data-template-table-object-handle]",
      ].join(", "),
    )
    .forEach((element) => element.remove());

  rootElement
    .querySelectorAll(
      [
        ".is-active-cell",
        ".is-selected-cell",
        ".is-selected-table-object",
        ".is-image-moving",
        ".is-image-resizing",
        ".is-table-column-hover",
        ".is-table-row-hover",
        ".is-table-resizing",
      ].join(", "),
    )
    .forEach((element) => {
      element.classList.remove(
        "is-active-cell",
        "is-selected-cell",
        "is-selected-table-object",
        "is-image-moving",
        "is-image-resizing",
        "is-table-column-hover",
        "is-table-row-hover",
        "is-table-resizing",
      );
    });
}

function applyRuntimeLayoutClasses(rootElement, options = {}) {
  const shellElement = rootElement.querySelector(".template-editor-runtime-shell");

  if (!shellElement) {
    return;
  }

  const isResponsiveLayout = options.layoutMode === "responsive" || options.responsiveLayout === true;

  shellElement.classList.add("examlist-template-editor-body");
  shellElement.classList.toggle("is-responsive-layout", isResponsiveLayout);
  rootElement.dataset.examlistTemplateEditorLayout = isResponsiveLayout ? "responsive" : "desktop";
}

function normalizeRuntimeOptions(options, instanceId, onRuntimeChange, onRuntimeSetHtml) {
  const documentRef = options.document || globalThis.document;

  assertBrowserDocument(documentRef);

  const rootElement = resolveRootElement(options.root || options.container, documentRef);

  if (!rootElement) {
    throw new Error("mountTemplateEditor() requires a valid root/container element.");
  }

  rootElement.classList.add("examlist-template-editor");
  rootElement.dataset.examlistTemplateEditorInstance = String(instanceId);

  const adapters = isObject(options.adapters) ? options.adapters : {};
  const resolveAssetUrl =
    typeof adapters.resolveAssetUrl === "function"
      ? adapters.resolveAssetUrl
      : typeof options.resolveAssetUrl === "function"
        ? options.resolveAssetUrl
        : null;
  const buildApiUrl =
    typeof adapters.buildApiUrl === "function"
      ? adapters.buildApiUrl
      : typeof resolveAssetUrl === "function"
        ? resolveAssetUrl
        : typeof options.buildApiUrl === "function"
          ? options.buildApiUrl
          : () => "";

  return {
    ...options,
    buildApiUrl,
    document: documentRef,
    idPrefix: String(options.idPrefix || `examlistTemplateEditor${instanceId}`),
    initialHtml: resolveInitialHtml(options),
    onChange: onRuntimeChange,
    onSetHtml: onRuntimeSetHtml,
    root: rootElement,
    tags: normalizeDataTags(options.dataTags || options.tags),
  };
}

export function getTemplateEditorRuntime() {
  return bundledTemplateEditorRuntime;
}

export const createTemplateEditor = bundledTemplateEditorRuntime.createTemplateEditor;
export const createTemplateEditorState = bundledTemplateEditorRuntime.createTemplateEditorState;
export const createTemplatePreviewState = bundledTemplateEditorRuntime.createTemplatePreviewState;
export const normalizeTemplateTagDefinition = bundledTemplateEditorRuntime.normalizeTemplateTagDefinition;
export const normalizeTemplateTagDefinitions = bundledTemplateEditorRuntime.normalizeTemplateTagDefinitions;

export function mountTemplateEditor(options = {}) {
  const instanceId = ++mountedInstanceCounter;
  const adapters = isObject(options.adapters) ? options.adapters : {};
  let currentTemplate = options.template ?? options.html ?? options.initialHtml ?? "";
  let currentSelectedPageId = resolveTemplatePageId(currentTemplate, options.selectedPageId);
  const initialPaperPreset = String(isObject(currentTemplate) ? currentTemplate.paperPreset || "" : "");
  let editorApi = null;
  let baselineSnapshot = "";
  let readOnlyState = options.readOnly === true || options.permissions?.canManageTemplates === false;
  let destroyed = false;
  let suppressedSetHtmlCallbackDepth = 0;
  const dirtyState = { isDirty: false };
  const overflowState = {
    hasOverflow: false,
    heightOverflow: 0,
    widthOverflow: 0,
  };
  const overflowByPage = new Map();
  const disposers = [];
  let overflowFrameId = 0;

  function getSurfaceElement() {
    return runtimeOptions?.root?.querySelector?.("[data-template-editor-runtime-surface]") || runtimeOptions?.surface || null;
  }

  function snapshotOverflowInfo() {
    return { ...overflowState };
  }

  function measureOverflowState() {
    if (destroyed) {
      return snapshotOverflowInfo();
    }

    const nextOverflow = getDocumentSurfaceOverflowInfo(getSurfaceElement());
    const pageKey = getSelectedTemplatePageKey(currentTemplate, currentSelectedPageId);
    const didChange =
      overflowState.hasOverflow !== nextOverflow.hasOverflow ||
      overflowState.heightOverflow !== nextOverflow.heightOverflow ||
      overflowState.widthOverflow !== nextOverflow.widthOverflow;

    overflowByPage.set(pageKey, { ...nextOverflow });
    Object.assign(overflowState, nextOverflow);
    runtimeOptions?.root?.classList?.toggle?.("has-template-editor-overflow", nextOverflow.hasOverflow);
    if (runtimeOptions?.root?.dataset) {
      runtimeOptions.root.dataset.examlistTemplateEditorOverflow = nextOverflow.hasOverflow ? "true" : "false";
    }

    if (didChange && !destroyed) {
      options.onOverflowChange?.(snapshotOverflowInfo(), getDocumentOverflowMessage(nextOverflow));
    }

    return snapshotOverflowInfo();
  }

  function getCombinedOverflowInfo() {
    const combinedOverflow = {
      hasOverflow: false,
      heightOverflow: 0,
      widthOverflow: 0,
    };

    overflowByPage.forEach((pageOverflow) => {
      combinedOverflow.hasOverflow ||= pageOverflow.hasOverflow;
      combinedOverflow.heightOverflow = Math.max(combinedOverflow.heightOverflow, pageOverflow.heightOverflow);
      combinedOverflow.widthOverflow = Math.max(combinedOverflow.widthOverflow, pageOverflow.widthOverflow);
    });

    return combinedOverflow;
  }

  function cancelScheduledOverflowCheck() {
    if (!overflowFrameId) {
      return;
    }

    const ownerWindow = runtimeOptions?.root?.ownerDocument?.defaultView || globalThis;

    if (ownerWindow.cancelAnimationFrame) {
      ownerWindow.cancelAnimationFrame(overflowFrameId);
    } else {
      ownerWindow.clearTimeout?.(overflowFrameId);
    }
    overflowFrameId = 0;
  }

  function updateOverflowState() {
    cancelScheduledOverflowCheck();
    return measureOverflowState();
  }

  function scheduleOverflowCheck() {
    if (destroyed || overflowFrameId) {
      return;
    }

    const ownerWindow = runtimeOptions?.root?.ownerDocument?.defaultView || globalThis;
    const runOverflowCheck = () => {
      overflowFrameId = 0;

      if (!destroyed) {
        measureOverflowState();
      }
    };

    overflowFrameId = ownerWindow.requestAnimationFrame
      ? ownerWindow.requestAnimationFrame(runOverflowCheck)
      : ownerWindow.setTimeout(runOverflowCheck, 0);
  }

  function refreshDirtyState() {
    if (destroyed) {
      return;
    }

    const nextSnapshot = createTemplateHtmlSnapshot(currentTemplate, runtimeOptions.document, options);

    setDirtyState(dirtyState, nextSnapshot !== baselineSnapshot, options.onDirtyChange);
  }

  function withoutSetHtmlCallback(callback) {
    suppressedSetHtmlCallbackDepth += 1;

    try {
      return callback();
    } finally {
      suppressedSetHtmlCallbackDepth -= 1;
    }
  }

  function isCandidateBlockModalOpen() {
    const ownerWindow = runtimeOptions?.root?.ownerDocument?.defaultView || globalThis;
    const modalController = ownerWindow?.ExamListCandidateBlockModalEditor || globalThis.ExamListCandidateBlockModalEditor;

    return (
      modalController?.isOpen?.() === true ||
      Boolean(
        runtimeOptions?.root?.querySelector?.(
          "[data-candidate-block-focus-layer], .examlist-candidate-block-focus-layer, [data-candidate-block-modal-editor-surface]",
        ),
      )
    );
  }

  const handleRuntimeChange = (html, rawRuntimeApi) => {
    if (destroyed) {
      return;
    }

    const rawHtml = String(html || "");
    // The candidate-block modal owns a temporary active editing surface. Its
    // runtime callback already serializes the underlying document separately,
    // and feeding a sanitized value back through setHtml while the modal is
    // open replaces that surface and recursively emits another change.
    const shouldDeferSanitization = isCandidateBlockModalOpen();
    if (shouldDeferSanitization) {
      setDirtyState(dirtyState, true, options.onDirtyChange);
      return;
    }

    let nextHtml = sanitizeResolvedHtml(rawHtml, options.document || globalThis.document, options);

    if (nextHtml !== rawHtml) {
      withoutSetHtmlCallback(() => {
        rawRuntimeApi.setHtml(nextHtml, { notify: false, resetHistory: false });
      });
      nextHtml = sanitizeResolvedHtml(rawRuntimeApi.getHtml(), options.document || globalThis.document, options);
    }

    currentTemplate = setTemplateDocumentHtml(currentTemplate, nextHtml, currentSelectedPageId, initialPaperPreset);
    refreshDirtyState();

    if (destroyed) {
      return;
    }

    scheduleOverflowCheck();
    options.onChange?.(currentTemplate, {
      editor: editorApi,
      html: nextHtml,
      runtime: rawRuntimeApi,
      selectedPageId: currentSelectedPageId,
    });
  };

  const handleRuntimeSetHtml = (html, rawRuntimeApi, context) => {
    if (destroyed || suppressedSetHtmlCallbackDepth > 0) {
      return;
    }

    options.onSetHtml?.(html, rawRuntimeApi, context);
  };

  const runtimeOptions = normalizeRuntimeOptions(options, instanceId, handleRuntimeChange, handleRuntimeSetHtml);
  const rootElement = runtimeOptions.root;
  currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);
  currentSelectedPageId = resolveTemplatePageId(currentTemplate, currentSelectedPageId);
  baselineSnapshot = createTemplateHtmlSnapshot(currentTemplate, runtimeOptions.document, options);
  const runtimeApi = bundledTemplateEditorRuntime.createTemplateEditor(runtimeOptions);

  currentTemplate = setTemplateDocumentHtml(
    currentTemplate,
    sanitizeResolvedHtml(runtimeApi.getHtml(), runtimeOptions.document, options),
    currentSelectedPageId,
    initialPaperPreset,
  );
  currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);
  baselineSnapshot = createTemplateHtmlSnapshot(currentTemplate, runtimeOptions.document, options);

  applyRuntimeLayoutClasses(rootElement, options);
  applyReadOnlyMode(rootElement, readOnlyState);

  function getHtml() {
    return sanitizeResolvedHtml(runtimeApi.getHtml(), runtimeOptions.document, options);
  }

  function getValue() {
    currentTemplate = setTemplateDocumentHtml(currentTemplate, getHtml(), currentSelectedPageId, initialPaperPreset);
    currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);
    return currentTemplate;
  }

  function setValue(nextValue, setOptions = {}) {
    if (destroyed) {
      return;
    }

    currentTemplate = sanitizeTemplateValue(nextValue, runtimeOptions.document, options);
    currentSelectedPageId = resolveTemplatePageId(
      currentTemplate,
      setOptions.selectedPageId === undefined ? currentSelectedPageId : setOptions.selectedPageId,
    );
    const nextHtml = typeof setOptions.html === "string"
      ? setOptions.html
      : getTemplateDocumentHtml(currentTemplate, currentSelectedPageId);
    const preparedHtml = sanitizeResolvedHtml(
      prepareTemplateDocumentHtml(currentTemplate, nextHtml, currentSelectedPageId),
      runtimeOptions.document,
      options,
    );

    overflowByPage.clear();
    runtimeApi.setHtml(preparedHtml, {
      notify: setOptions.notify === true,
      resetHistory: setOptions.resetHistory !== false,
    });

    if (destroyed) {
      return;
    }

    currentTemplate = setTemplateDocumentHtml(
      currentTemplate,
      getHtml(),
      currentSelectedPageId,
      initialPaperPreset,
    );
    currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);

    if (setOptions.markClean === true) {
      baselineSnapshot = createTemplateHtmlSnapshot(currentTemplate, runtimeOptions.document, options);
      setDirtyState(dirtyState, false, options.onDirtyChange);
    } else {
      refreshDirtyState();
    }

    scheduleOverflowCheck();
  }

  function getSelectedPageId() {
    return currentSelectedPageId;
  }

  function setSelectedPage(selectedPageId, setOptions = {}) {
    if (destroyed) {
      return currentSelectedPageId;
    }

    currentTemplate = setTemplateDocumentHtml(currentTemplate, getHtml(), currentSelectedPageId, initialPaperPreset);
    currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);
    updateOverflowState();

    if (destroyed) {
      return currentSelectedPageId;
    }

    currentSelectedPageId = resolveTemplatePageId(currentTemplate, selectedPageId);
    const nextHtml = sanitizeResolvedHtml(
      prepareTemplateDocumentHtml(
        currentTemplate,
        getTemplateDocumentHtml(currentTemplate, currentSelectedPageId),
        currentSelectedPageId,
      ),
      runtimeOptions.document,
      options,
    );

    runtimeApi.setHtml(nextHtml, {
      notify: setOptions.notify === true,
      resetHistory: setOptions.resetHistory !== false,
    });

    if (destroyed) {
      return currentSelectedPageId;
    }

    currentTemplate = setTemplateDocumentHtml(
      currentTemplate,
      getHtml(),
      currentSelectedPageId,
      initialPaperPreset,
    );
    currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);

    if (setOptions.markClean === true) {
      baselineSnapshot = createTemplateHtmlSnapshot(currentTemplate, runtimeOptions.document, options);
      setDirtyState(dirtyState, false, options.onDirtyChange);
    } else {
      refreshDirtyState();
    }

    scheduleOverflowCheck();

    return currentSelectedPageId;
  }

  function setHtml(nextHtml, setOptions = {}) {
    if (destroyed) {
      return "";
    }

    const preparedHtml = sanitizeResolvedHtml(nextHtml, runtimeOptions.document, options);

    runtimeApi.setHtml(preparedHtml, setOptions);

    if (destroyed) {
      return "";
    }

    currentTemplate = setTemplateDocumentHtml(
      currentTemplate,
      getHtml(),
      currentSelectedPageId,
      initialPaperPreset,
    );
    currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);
    refreshDirtyState();
    scheduleOverflowCheck();
    return getHtml();
  }

  function sync() {
    if (destroyed) {
      return currentTemplate;
    }

    runtimeApi.sync();
    return getValue();
  }

  function measureAllPageOverflow(template) {
    if (destroyed) {
      return getCombinedOverflowInfo();
    }

    cancelScheduledOverflowCheck();
    const pages = getTemplatePages(template);

    if (pages.length === 0) {
      updateOverflowState();
      return getCombinedOverflowInfo();
    }

    const activeHtml = getHtml();
    const activePageKey = getSelectedTemplatePageKey(template, currentSelectedPageId);
    const currentPageKeys = new Set();

    withoutSetHtmlCallback(() => {
      try {
        pages.forEach((page, index) => {
          const pageKey = getTemplatePageKey(template, page, index);
          const pageHtml = pageKey === activePageKey
            ? activeHtml
            : sanitizeResolvedHtml(
                prepareSpecificTemplatePageHtml(template, page, page?.settings?.documentHtml),
                runtimeOptions.document,
                options,
              );

          currentPageKeys.add(pageKey);
          runtimeApi.setHtml(pageHtml, { notify: false, resetHistory: false });
          overflowByPage.set(pageKey, {
            ...getDocumentSurfaceOverflowInfo(getSurfaceElement()),
          });
        });
      } finally {
        if (!destroyed) {
          runtimeApi.setHtml(activeHtml, { notify: false, resetHistory: false });
        }
      }
    });

    Array.from(overflowByPage.keys()).forEach((pageKey) => {
      if (!currentPageKeys.has(pageKey)) {
        overflowByPage.delete(pageKey);
      }
    });
    measureOverflowState();
    return getCombinedOverflowInfo();
  }

  async function preview(context = {}) {
    const html = getHtml();
    const template = getValue();
    const hasPreviewContext = isObject(context) && Object.keys(context).length > 0;
    let sampleData = {};

    if (isObject(context?.sampleData)) {
      sampleData = context.sampleData;
    } else if (hasPreviewContext) {
      sampleData = context;
    } else {
      const configuredPreviewData =
        typeof options.getPreviewData === "function" ? options.getPreviewData() : options.previewData;

      sampleData = isObject(configuredPreviewData) ? configuredPreviewData : {};
    }

    if (typeof adapters.previewPdf === "function") {
      return adapters.previewPdf({
        editor: editorApi,
        html,
        sampleData,
        template,
      });
    }

    return {
      html: runtimeApi.render(sampleData, html),
      pageCount: 1,
      warnings: [],
    };
  }

  async function save(context = {}) {
    if (destroyed) {
      throw new Error("Cannot save a destroyed template editor.");
    }

    const html = getHtml();
    const template = getValue();
    const overflowInfo = measureAllPageOverflow(template);

    if (destroyed) {
      return template;
    }

    if (overflowInfo.hasOverflow && options.blockSaveOnOverflow !== false) {
      const error = new Error(getDocumentOverflowMessage(overflowInfo));

      error.code = "TEMPLATE_EDITOR_OVERFLOW";
      error.overflow = overflowInfo;
      throw error;
    }

    const savedTemplate =
      typeof adapters.saveTemplate === "function"
        ? await adapters.saveTemplate({
            ...context,
            editor: editorApi,
            html,
            template,
          })
        : template;

    if (destroyed) {
      return savedTemplate ?? template;
    }

    const hasCanonicalSavedValue = isObject(savedTemplate) || typeof savedTemplate === "string";

    currentTemplate = sanitizeTemplateValue(
      hasCanonicalSavedValue ? savedTemplate : template,
      runtimeOptions.document,
      options,
    );
    currentSelectedPageId = resolveTemplatePageId(currentTemplate, currentSelectedPageId);
    const canonicalHtml = sanitizeResolvedHtml(
      prepareTemplateDocumentHtml(
        currentTemplate,
        getTemplateDocumentHtml(currentTemplate, currentSelectedPageId),
        currentSelectedPageId,
      ),
      runtimeOptions.document,
      options,
    );

    overflowByPage.clear();
    withoutSetHtmlCallback(() => {
      runtimeApi.setHtml(canonicalHtml, {
        notify: false,
        resetHistory: hasCanonicalSavedValue,
      });
    });
    currentTemplate = setTemplateDocumentHtml(
      currentTemplate,
      getHtml(),
      currentSelectedPageId,
      initialPaperPreset,
    );
    currentTemplate = sanitizeTemplateValue(currentTemplate, runtimeOptions.document, options);
    baselineSnapshot = createTemplateHtmlSnapshot(currentTemplate, runtimeOptions.document, options);
    setDirtyState(dirtyState, false, options.onDirtyChange);

    if (!destroyed) {
      scheduleOverflowCheck();
    }

    return currentTemplate;
  }

  function insertHtml(nextHtml) {
    if (destroyed || readOnlyState) {
      return false;
    }

    const sanitizedHtml = sanitizeResolvedHtml(nextHtml, runtimeOptions.document, options);

    if (!sanitizedHtml.trim()) {
      return false;
    }

    return runtimeApi.insertHtml(sanitizedHtml) !== false;
  }

  function insertImageSource(source, caption = "이미지") {
    const markup = buildUploadedImageMarkup(
      {
        alt: caption,
        src: source,
        title: caption,
      },
      null,
      runtimeOptions,
    );

    return markup ? insertHtml(markup) : false;
  }

  function insertUploadedImage(uploadResult, context = {}) {
    if (destroyed || readOnlyState) {
      return false;
    }

    const markup = buildUploadedImageMarkup(uploadResult, context.file, runtimeOptions);

    if (!markup) {
      return false;
    }

    return insertHtml(markup);
  }

  async function insertImage(file, context = {}) {
    if (!file || destroyed || readOnlyState) {
      return false;
    }

    if (typeof adapters.uploadImage !== "function") {
      const FileReaderConstructor = runtimeOptions.document?.defaultView?.FileReader || globalThis.FileReader;

      if (typeof FileReaderConstructor !== "function") {
        return false;
      }

      const source = await new Promise((resolveRead, rejectRead) => {
        const reader = new FileReaderConstructor();

        reader.addEventListener("load", () => resolveRead(String(reader.result || "")), { once: true });
        reader.addEventListener("error", () => rejectRead(reader.error || new Error("Failed to read image file.")), {
          once: true,
        });
        reader.readAsDataURL(file);
      });

      if (destroyed || readOnlyState) {
        return false;
      }

      return insertImageSource(source, file.name);
    }

    const uploadResult = await adapters.uploadImage({
      ...context,
      editor: editorApi,
      file,
      html: getHtml(),
      template: getValue(),
    });

    if (destroyed || readOnlyState) {
      return false;
    }

    return insertUploadedImage(uploadResult, { ...context, file });
  }

  function focus() {
    if (destroyed) {
      return;
    }

    rootElement.querySelector("[data-template-editor-runtime-surface]")?.focus();
  }

  function setReadOnly(nextReadOnly) {
    if (destroyed) {
      return;
    }

    readOnlyState = Boolean(nextReadOnly);
    applyReadOnlyMode(rootElement, readOnlyState);
  }

  const surfaceElement = getSurfaceElement();
  const ownerWindow = rootElement.ownerDocument?.defaultView || globalThis;
  const handlePotentialOverflowChange = () => scheduleOverflowCheck();

  surfaceElement?.addEventListener?.("input", handlePotentialOverflowChange);
  surfaceElement?.addEventListener?.("change", handlePotentialOverflowChange);
  ownerWindow.addEventListener?.("resize", handlePotentialOverflowChange);
  disposers.push(() => {
    surfaceElement?.removeEventListener?.("input", handlePotentialOverflowChange);
    surfaceElement?.removeEventListener?.("change", handlePotentialOverflowChange);
    ownerWindow.removeEventListener?.("resize", handlePotentialOverflowChange);
  });
  scheduleOverflowCheck();

  if (typeof adapters.uploadImage === "function") {
    const handleUploadInputChange = (event) => {
      const target = event.target;

      if (
        !target ||
        String(target.tagName || "").toUpperCase() !== "INPUT" ||
        target.type !== "file" ||
        !target.classList?.contains("upload-file-input")
      ) {
        return;
      }

      const file = target.files?.[0] || null;

      if (!file) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation?.();

      insertImage(file, { source: "toolbar" }).catch((error) => {
        if (destroyed) {
          return;
        }

        options.onUploadError?.(error, {
          editor: editorApi,
          file,
        });

        if (destroyed) {
          return;
        }

        const CustomEventConstructor = rootElement.ownerDocument?.defaultView?.CustomEvent;

        if (typeof CustomEventConstructor === "function") {
          rootElement.dispatchEvent(
            new CustomEventConstructor("examlist-template-editor:image-upload-error", {
              bubbles: true,
              detail: { error, file },
            }),
          );
        }
      });

      target.value = "";
    };

    rootElement.addEventListener("change", handleUploadInputChange, true);
    disposers.push(() => rootElement.removeEventListener("change", handleUploadInputChange, true));
  }

  function destroy() {
    if (destroyed) {
      return;
    }

    destroyed = true;
    cancelScheduledOverflowCheck();
    disposers.splice(0).forEach((dispose) => dispose());
    runtimeApi.destroy();
    removeTransientRuntimeNodes(rootElement);
    rootElement.classList.remove("is-read-only");
    rootElement.classList.remove("has-template-editor-overflow");
    delete rootElement.dataset.examlistTemplateEditorReadonly;
    delete rootElement.dataset.examlistTemplateEditorOverflow;

    if (options.clearRootOnDestroy === true) {
      rootElement.replaceChildren();
      rootElement.classList.remove("examlist-template-editor", "template-editor-runtime");
      delete rootElement.dataset.examlistTemplateEditorInstance;
    }
  }

  editorApi = Object.freeze({
    applyCommand: runtimeApi.applyCommand,
    clearTableObjectHoverState: (...args) => runtimeApi.clearTableObjectHoverState(...args),
    clearTableObjectSelection: (...args) => runtimeApi.clearTableObjectSelection(...args),
    destroy,
    focus,
    getHtml,
    getRuntime: () => runtimeApi,
    getOverflowInfo: updateOverflowState,
    getSelectedPageId,
    getValue,
    handleImageResizeStart: (...args) => runtimeApi.handleImageResizeStart(...args),
    insertHtml,
    insertImage,
    insertImageFile: insertImage,
    insertImageSource,
    insertUploadedImage,
    insertTag: runtimeApi.insertTag,
    isDirty: () => dirtyState.isDirty,
    preview,
    redo: runtimeApi.redo,
    render: runtimeApi.render,
    renderInto: runtimeApi.renderInto,
    renderPagePropertiesPanel: (...args) => runtimeApi.renderPagePropertiesPanel(...args),
    renderTagPanel: (...args) => runtimeApi.renderTagPanel(...args),
    renderToolbar: (...args) => runtimeApi.renderToolbar(...args),
    save,
    setHtml,
    setReadOnly,
    setSelectedPage,
    setValue,
    state: runtimeApi.state,
    sync,
    undo: runtimeApi.undo,
    updateImageSelectionOverlay: (...args) => runtimeApi.updateImageSelectionOverlay(...args),
    updateTableObjectOverlay: (...args) => runtimeApi.updateTableObjectOverlay(...args),
    uploadImage: insertImage,
  });

  return editorApi;
}
