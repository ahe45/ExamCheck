# Changelog

## 1.1.12

- Replaced the initial blank canvas paragraph when inserting a table and reused the existing table caret host when deleting it, preventing undeletable extra blank lines.

## 1.1.11

- Stopped sanitized runtime change callbacks from re-entering document synchronization.
- Excluded object-flow spacer elements and identifiers from serialized HTML while preserving them in the live editing DOM.

## 1.1.10

- Avoided redundant flow-spacer attribute and style mutations during repeated document synchronization.

## 1.1.9

- Reused valid table flow spacers across move, resize, line-break, and document-sync passes instead of deleting and rebuilding the same runtime layout state.

## 1.1.8

- Replaced per-cell table layout work during pointer resizing with a lightweight visual preview and a single final layout pass on pointer release.

## 1.1.7

- Prioritized table bottom-border hit testing over the following caret host so the table can be selected from every edge.

## 1.1.6

- Coalesced rapid table and object pointer moves to one layout update per animation frame, preventing large table resize gestures from blocking the editor.

## 1.1.0

- Synchronized the generated runtime and scoped CSS with ExamList commit `8915a8e`, including OPT10 and the 19px page-number bottom spacing.
- Added source/artifact fingerprints and strict stale-build verification for both generated outputs.
- Added multi-page selection, page switching, preview-data defaults, raw runtime export, and the missing advanced runtime methods.
- Added A3/A4/B5/Letter/Legal, orientation, safe-area, page-number, recognition-mark, other-room, cover, and candidate-grid normalization.
- Added current data-tag grouping, generation-unit, canvas zoom, candidate-block geometry/table, object size/alignment, Code128/QR, and generated-object APIs.
- Added DOM token, sanitizer, overflow, image geometry, object-flow, table-segment, and candidate-block boundary/keyboard/table APIs.
- Sanitized mounted editor HTML by default and blocked overflow saves with `TEMPLATE_EDITOR_OVERFLOW` unless explicitly disabled.
- Extended sanitization, dirty tracking, and overflow validation across every template page; canonical save responses now rehydrate the mounted editor, and pending async work is ignored after destroy.
- Restored candidate-block table minimum sizing and made DOM measurement helpers safe for owner-document/iframe contexts and browserless imports.
- Added current multi-page template and full data-tag fixtures with OPT1 through OPT10.
- Added the `examlist-template-editor/dom` and fixture export paths, exact per-entry TypeScript value surfaces, and an expanded public contract.
- Made generated artifact checks CRLF/LF independent and changed consumer verification to install the actual packed tarball.

## 1.0.2

- Kept the packaged editor in desktop four-column layout by default, even when the host app viewport is narrow.
- Added `layoutMode: "responsive"` / `responsiveLayout: true` opt-in for projects that explicitly want the stacked responsive layout.
- Added a browser regression test that mounts the editor in a narrow viewport and verifies the desktop layout remains intact.

## 1.0.1

- Fixed the packaged runtime layout so the editor uses the same four-column toolbar, tag panel, canvas, and page-properties arrangement as the ExamList editor.
- Added scoped form-control resets to reduce interference from host application global `button`, `input`, and `select` styles.
- Added a browser regression test for runtime layout placement and host CSS isolation.

## 1.0.0

- Promoted the portable editor package to the first stable GitHub-installable release.
- Added public image upload adapter support for `editor.insertImage(file)`, `editor.uploadImage(file)`, and toolbar file input insertion.
- Added TypeScript declarations for upload adapter requests and uploaded image results.
- Extended the Playwright browser scenario to verify adapter-backed image upload from both the public API and toolbar file input.
- Updated README and integration/API docs for the `v1.0.0` install path and stable adapter contract.

## 0.7.1

- Fixed standalone GitHub Actions builds by reusing committed runtime/CSS artifacts when the ExamList source tree is not available.

## 0.7.0

- Added browser `mountTemplateEditor()` API.
- Added bundled runtime generated from `client/template-editor-runtime`.
- Added scoped CSS export at `examlist-template-editor/styles.css`.
- Added runtime adapter boundary for save, preview, and asset URL behavior.
- Added Playwright browser scenario covering multiple instances, value sync, preview, save, read-only mode, CSS scoping, and destroy cleanup.
- Added TypeScript declarations for runtime options and mounted editor API.

## 0.1.0

- Added portable data tag core modules.
- Added ESM package entry points for `examlist-template-editor` and `examlist-template-editor/core`.
- Added type declarations for public API.
- Added independent unit tests and consumer install verification.
