# ExamCheck consumer patch

Based on examlist-template-editor 1.1.13. Mixed text and data-tag formatting now resolves replaced token nodes by their position and tag key within the original editing surface before restoring the prepared inline styles. No upstream release is implied by this consumer version.
