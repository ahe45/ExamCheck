# Public API

The package exposes four JavaScript entry points and one CSS entry:

- `examlist-template-editor`: all public core, DOM, and runtime APIs
- `examlist-template-editor/core`: import-safe normalization, formatting, geometry, markup, and low-level measurement APIs
- `examlist-template-editor/dom`: browser DOM normalization and measurement APIs
- `examlist-template-editor/runtime`: raw and mounted editor APIs
- `examlist-template-editor/styles.css`: scoped editor styles

The complete TypeScript contract is in `types/index.d.ts`.

The `core` entry itself is safe to import without browser globals. Pure normalization, formatting, and markup helpers also run in Node.js. Canvas, candidate-block role, and object size/alignment measurement helpers operate on DOM elements and therefore require a browser DOM when called.

## Data tags

Formatting and validation:

- `getDataTagDefinitionKey()`
- `getDataTagFormatType()`
- `isDataTagFormatSupported()`
- `getDataTagSampleValueConstraint()`
- `getDataTagSampleValueError()`
- `normalizeDataTagSampleValue()`
- `buildDataTagSampleValueErrors()`
- `formatDataTagValue()`
- `formatDataTagSampleValue()`
- `getDataTagFormatOptions()`
- `getDataTagFormatTokenGuides()`
- `isDataTagFormatValid()`
- `normalizeDataTagFormat()`
- `renderDataTagFormatPreview()`

Definition and settings helpers:

- `normalizeDataTagDefinition()`
- `flattenDataTagDefinitions()`
- `findDataTagDefinitionByKey()`
- `buildDefaultDataTagSampleValues()`
- `buildDefaultDataTagEmptyValueData()`
- `createDataTagSettingsPayload()`
- `normalizeDataTagViewOptions()`
- `dataTagAccordionGroups`
- `dataTagFallbackDefinitions`
- `getDataTagGroupForKey()`
- `renderDataTagIcon()`
- `isVisibleTemplateTag()`

Current built-in candidate fields include `candidate.opt1` through `candidate.opt10`.

## Layout and page settings

`normalizePageSettings(settings, paper, pageType)` mirrors the current server layout contract for:

- safe area
- page number preset and position
- recognition mark size and offsets
- other-room pages
- candidate block settings and legacy aliases
- cover-page feature disabling

Runtime page conversion APIs:

- `getRuntimePageSettings()`
- `readRuntimePageSettingsFromHtml()`
- `writeRuntimePageSettingsToHtml()`
- `applyPaperSettingsToTemplate()`
- `applySafeAreaToTemplate()`
- `prepareTemplatePageHtml()`
- `syncTemplatePageSettingsFromHtml()`

Supported paper sizes are A3, A4, B5, Letter, and Legal. Template dimensions use points; runtime page-property fields use millimetres.

Generation-unit APIs:

- `getGenerationUnitFieldOptions()`
- `normalizeGenerationUnitFields()`
- `getTemplateGenerationUnitFields()`
- `writeGenerationUnitSettingsToTemplate()`
- `formatGenerationUnitFieldsSummary()`

## Candidate blocks

Configuration:

- `candidateBlockGridDefaults`
- `candidateBlockGridSortOptions`
- `normalizeCandidateBlockGridConfig()`
- `normalizeCandidateBlockGridSettings()`
- `normalizeCandidateBlockGridSortKey()`
- `normalizeCandidateBlockGridSortDirection()`
- `getCandidateBlockGridConfig()`
- `canUseCandidateBlockGrid()`
- `getCandidateBlockGridTotal()`

OPT10 and `candidate.opt10` normalize to the `opt10` server sort key.

Portable geometry and DOM helpers include:

- template source/preview roles
- focus layout and viewport-to-host coordinate conversion
- boundary and native-delete protection
- keyboard-delete target resolution
- table cell mapping, minimum sizing, size distribution, and table normalization

These lower-level APIs are intended for integrations that build a custom candidate-block controller around the packaged runtime.

## Generated objects

- `buildCode128BSequence()`
- `buildCode128Svg()`
- `getGeneratedObjectConfig()`
- `getGeneratedObjectSourceOptions()`
- `resolveGeneratedObjectPreviewValue()`
- `buildGeneratedObjectPreviewData()`
- `buildGeneratedObjectSvg()`
- `createGeneratedObjectSvgDataUrl()`
- `buildGeneratedObjectMarkup()`

Photo URL, file ID, and current date values are supplied through function options; the core does not contain an ExamList API path.

## DOM APIs

Sanitization:

- `sanitizeNodeTree()`
- `stripTransientDocumentState()`
- `normalizeDocumentFontNodes()`
- `sanitizeTemplateEditorHtml()`

`sanitizeTemplateEditorHtml()` removes blocked tags, inline event handlers, unsafe image sources, unsupported attributes/styles, and transient editor overlays. It also normalizes stored token nodes.

Tokens and document objects:

- `normalizeDocumentTokenTag()`
- `createDocumentTokenElement()`
- `buildDocumentTokenHtml()`
- `normalizeDocumentTokenNodes()`
- `getDocumentElementDisplayScale()`
- `getObjectResizeDirections()`
- `normalizeObjectTableSegmentSizes()`
- `syncTemplateEditorObjectFlowObjects()`
- `reflowTemplateEditorObjectRows()`

Object-flow functions preserve the current ExamList compatibility contract. Reflow is currently disabled by design and removes unsupported transient flow state.

Overflow:

- `getDocumentContentRoot()`
- `getDocumentSurfaceOverflowInfo()`
- `getDocumentOverflowMessage()`

Overflow uses a 4px tolerance and ignores transient selection controls and empty trailing paragraphs.

## Mounted runtime

```js
const editor = mountTemplateEditor({
  root,
  template,
  selectedPageId,
  dataTags,
  adapters,
});
```

Important mount options:

- `template`, `html`, or `initialHtml`
- `selectedPageId`
- `dataTags` or `tags`
- `readOnly` or `permissions.canManageTemplates`
- `layoutMode: "desktop" | "responsive"`
- `previewData` or `getPreviewData()`
- `sanitizeHtml` (default `true`)
- `blockSaveOnOverflow` (default `true`)
- `onChange()`, `onDirtyChange()`, `onOverflowChange()`

Adapters:

- `saveTemplate({ editor, html, template, ...context })`
- `previewPdf({ editor, html, sampleData, template })`
- `uploadImage({ editor, file, html, template, ...context })`
- `buildApiUrl(path)`
- `resolveAssetUrl(path)`

Mounted value and lifecycle methods:

- `getValue()`, `setValue()`
- `getHtml()`, `setHtml()`, `sync()`
- `getSelectedPageId()`, `setSelectedPage()`
- `getOverflowInfo()`, `isDirty()`
- `preview()`, `save()`
- `setReadOnly()`, `focus()`, `destroy()`

Editing methods:

- `insertHtml()`, `insertTag()`
- `insertImage()`, `insertImageFile()`, `insertUploadedImage()`
- `undo()`, `redo()`
- `render()`, `renderInto()`

Advanced runtime forwarding:

- `state`, `getRuntime()`
- `clearTableObjectHoverState()`
- `clearTableObjectSelection()`
- `handleImageResizeStart()`
- `renderToolbar()`, `renderTagPanel()`, `renderPagePropertiesPanel()`
- `updateImageSelectionOverlay()`, `updateTableObjectOverlay()`

`save()` throws an error with `code: "TEMPLATE_EDITOR_OVERFLOW"` and an `overflow` payload when content exceeds the page and blocking is enabled.

## Raw runtime

`createTemplateEditor(options)` exposes the current generated runtime factory directly. `getTemplateEditorRuntime()` returns the whole bundled runtime module. Use the mounted wrapper unless the consumer already owns the runtime hosts and lifecycle.

## Template shape

The mounted editor reads and writes page HTML at:

```text
template.layout.pages[].settings.documentHtml
```

Legacy string and single-document locations remain supported:

- `template.documentHtml`
- `template.html`
- `template.settings.documentHtml`
- a raw HTML string

The current fixture is exported at `examlist-template-editor/fixtures/templates/current-layout-template.json`.

## CSS

```js
import "examlist-template-editor/styles.css";
```

Generated selectors are scoped under `.examlist-template-editor`. The default layout is the ExamList four-column desktop layout; responsive stacking is opt-in.
