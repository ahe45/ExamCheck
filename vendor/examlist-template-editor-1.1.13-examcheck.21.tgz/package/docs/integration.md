# Integration Guide

## 1. Install a fixed release

```bash
npm install github:ahe45/template-editor#v1.1.0
```

Private repository over SSH:

```bash
npm install git+ssh://git@github.com/ahe45/template-editor.git#v1.1.0
```

CI needs a deploy key or token that can read the repository. Do not depend on a moving branch in production.

## 2. Import the editor and CSS

```js
import { mountTemplateEditor } from "examlist-template-editor";
import "examlist-template-editor/styles.css";
```

Give the editor root enough horizontal space for the default four-column layout. Use `layoutMode: "responsive"` only when the host intentionally wants the columns stacked.

## 3. Supply a template and data tags

```js
const editor = mountTemplateEditor({
  root: document.getElementById("editor"),
  template,
  selectedPageId: template.layout.pages[0].id,
  dataTags,
});
```

The primary current template shape is:

```text
template
└─ layout
   ├─ paper
   └─ pages[]
      ├─ id, type, widthPt, heightPt
      └─ settings
         ├─ documentHtml
         ├─ safeArea
         ├─ pageNumber
         ├─ recognitionMarks
         ├─ otherRoomPage
         └─ candidateBlockGrid
```

Use the exported current fixture when validating a new consumer:

```js
import template from "examlist-template-editor/fixtures/templates/current-layout-template.json" with { type: "json" };
import dataTags from "examlist-template-editor/fixtures/data-tags/examlist-data-tags.json" with { type: "json" };
```

## 4. Connect project adapters

The package does not call an ExamList API path. The consumer owns persistence, authentication, PDF rendering, and file storage.

```js
const editor = mountTemplateEditor({
  root,
  template,
  dataTags,
  adapters: {
    saveTemplate: async ({ template, html, editor, ...context }) => {
      const saved = await api.saveTemplate(template, context);
      return saved;
    },
    previewPdf: async ({ template, html, sampleData, editor }) => {
      return api.previewTemplate({ template, html, sampleData });
    },
    uploadImage: async ({ file, template, html, editor, ...context }) => {
      const uploaded = await api.uploadImage(file, context);
      return {
        url: uploaded.url,
        alt: file.name,
        width: uploaded.width,
        height: uploaded.height,
      };
    },
    buildApiUrl: (path) => new URL(path, location.origin).href,
  },
});
```

`previewPdf` is optional. Without it, `preview()` returns locally rendered HTML. `uploadImage` is optional; without it, the runtime uses a local data URL.

## 5. Keep consumer state synchronized

```js
const editor = mountTemplateEditor({
  root,
  template,
  dataTags,
  onChange(nextTemplate, context) {
    template = nextTemplate;
    renderDirtyState(editor.isDirty());
    console.debug(context.selectedPageId, context.html);
  },
  onDirtyChange(isDirty) {
    setNavigationGuard(isDirty);
  },
});
```

For multiple pages:

```js
editor.setSelectedPage("page-2");

editor.setValue(nextTemplate, {
  selectedPageId: "page-3",
  markClean: true,
});
```

Switching pages commits the outgoing page before loading the incoming page. Paper size, orientation, and safe-area values in runtime HTML are synchronized back into the structured template.

## 6. Handle overflow and save errors

The mounted editor sanitizes HTML and blocks overflow saves by default.

```js
const editor = mountTemplateEditor({
  root,
  template,
  onOverflowChange(info, message) {
    warningElement.textContent = info.hasOverflow ? message : "";
  },
});

try {
  await editor.save({ reason: "user-submit" });
} catch (error) {
  if (error.code === "TEMPLATE_EDITOR_OVERFLOW") {
    focusOverflowHelp(error.overflow);
  } else {
    throw error;
  }
}
```

Only disable `sanitizeHtml` when the consumer applies an equivalent trusted policy. Set `blockSaveOnOverflow: false` only when the consumer performs its own blocking decision.

## 7. Preview defaults

```js
mountTemplateEditor({
  root,
  template,
  previewData: { name: "홍길동", examineeNo: "123100001" },
});
```

`getPreviewData()` may be used instead when preview values change over time. An explicit `editor.preview(data)` call overrides the configured defaults.

## 8. Read-only mode

```js
const editor = mountTemplateEditor({
  root,
  template,
  permissions: { canManageTemplates: false },
});

editor.setReadOnly(false);
```

## 9. Cleanup

Always destroy the editor before unmounting its container:

```js
editor.destroy();
root.remove();
```

This removes runtime listeners, overflow listeners, selection overlays, and instance state.

## 10. Core-only and DOM-only use

Core modules can be used without mounting:

```js
import {
  buildGeneratedObjectSvg,
  normalizeGenerationUnitFields,
  normalizePageSettings,
} from "examlist-template-editor/core";
```

DOM modules are imported separately when a custom editor controller owns the page:

```js
import {
  normalizeCandidateBlockTables,
  normalizeDocumentTokenNodes,
  sanitizeTemplateEditorHtml,
} from "examlist-template-editor/dom";
```

The package entry points are import-safe in Node.js, but functions that manipulate real elements require a browser `Document`.

## 11. Consumer acceptance check

`npm run verify` is a maintainer/CI command for a source checkout. It is not an installed-package command, and the published package does not need to include its build and test scripts.

Before replacing an existing editor, verify:

1. CSS is imported once.
2. A current fixture loads and saves without losing page settings.
3. OPT10 appears in data tags and candidate sort options.
4. Preview and upload adapters receive the expected payload.
5. Overflow prevents the save adapter from running.
6. Read-only controls cannot edit the surface.
7. Two mounted instances have no duplicate IDs.
8. `destroy()` leaves no editor listeners behind.
