# Migration Notes

Source repository: `ExamList`

Original extraction baseline: `132412d` (2026-06-20)

Current synchronized baseline: `8915a8e` (2026-08-26)

Portable package release target: `v1.1.0`

## Current synchronization result

The upstream delta from `132412d` through `8915a8e` contained two editor-facing changes:

- candidate options and sort aliases extended through OPT10
- candidate-block page-number bottom padding changed from 14px to 19px

Both changes are present in the package. The synchronization also completed reusable core and DOM groups that existed in the current application but were not previously exposed by the portable package.

## Generated runtime and CSS

| Package artifact | ExamList source | Package adaptation |
| --- | --- | --- |
| `src/runtime/template-editor-runtime.bundle.js` | `client/template-editor-runtime/client/template-editor-runtime/manifest.js` and its 91 required scripts | Concatenated in manifest order. The strict-ESM table interaction compatibility declarations are inserted only after exact precondition checks. |
| `src/styles/template-editor.css` | runtime CSS plus `styles/features/template-editor.css` and all imported feature CSS | Imports are resolved, selectors are scoped under `.examlist-template-editor`, and package layout compatibility/reset rules are appended. |
| `src/generated-artifact-fingerprints.json` | all runtime and CSS source files listed above | Records source and artifact SHA-256 fingerprints so standalone builds cannot silently accept modified or stale generated files. |

`npm run check:source-sync` regenerates the expected result when the parent ExamList source is present. In a standalone package checkout it verifies the committed fingerprint and artifact hash. Source and generated artifact text is canonicalized to LF before comparison and hashing so Windows CRLF checkout policy does not change the result.

## Core modules

| Package module group | Primary ExamList source | Adaptation |
| --- | --- | --- |
| data tag format/value/sample modules | `client/features/template-editor/data-tag-*.js` | Package-local imports; browser storage/event use remains guarded. |
| `data-tags-config.js` | `client/features/template-editor/data-tags-config.js` | Current group/fallback definitions, including OPT10. |
| `data-tag-view-options.js` | `client/features/template-editor/data-tags-view-options.js` | Pure defaults and normalization only; app storage/event dispatch stays outside. |
| `layout-settings.js` | `client/features/template-editor/layout-settings.js` | Pure form, margin, and paper normalization. |
| `template-page-settings.js` | `page-settings-adapter.js`, `editor-runtime-document-state.js` | Browser-independent runtime HTML ↔ template conversion with page selection supplied as an argument. |
| `template-layout-page-settings.js` | `server/modules/pdf-templates/layout-page-settings.js` | CommonJS/app imports replaced with package-local normalizers; server page-number, recognition-mark, other-room, cover, and candidate-grid rules retained. |
| `candidate-block-grid-config.js` | client config and server candidate sort | Current bounds, legacy aliases, and OPT1–OPT10 sort keys. |
| candidate focus/pixel/role modules | matching client modules | App-neutral calculation and DOM-role contracts copied with package-local imports. |
| generated object and Code128 modules | `generated-objects-*.js`, `code128-svg.js` | API/photo/date values are passed as options; no fixed ExamList asset path. |
| `generation-unit-settings.js` | matching client module | Candidate sort options reused locally; no app state. |
| `canvas-zoom.js` | matching client module | `appState` replaced with an `editorState` argument; overlay refresh uses a callback. |
| object size/alignment modules | matching client modules | Candidate-table and object-flow operations are injected instead of resolved through app globals. |

## DOM modules

| Package module group | Primary ExamList source | Adaptation |
| --- | --- | --- |
| document sanitizer | `document-editor-sanitizer.js`, `document-editor-root.js` | Owner-document-safe node checks plus a public HTML wrapper; token nodes are normalized after sanitization. |
| document tokens | `document-editor-tokens.js` | Package-local escaping and format support. |
| document overflow | `document-overflow.js` | Owner-document-safe constructors; measurement rules and Korean save message retained. |
| document image utilities | `document-image-utils.js` | Copied geometry contract. |
| object flow/table segments | `object-flow-reflow.js`, `object-size-table-segments.js` | Current compatibility behavior retained; unsupported transient flow state is removed. |
| candidate boundary/keyboard | matching candidate-block client modules | The small app DOM helper import is replaced with the equivalent local selector helper. |
| candidate table layout/normalizer | matching candidate-block client modules | Imports point to portable candidate config/pixel modules. |

## Mounted runtime wrapper

`src/runtime/index.js` is package-owned integration code around the generated runtime. In `v1.1.0` it adds:

- named raw `createTemplateEditor` export and complete raw runtime typing
- forwarding of runtime state, render panels, selection clearing, resize, and overlay APIs
- mutable selected-page state and safe page switching
- page size/orientation/safe-area hydration and commit
- configured preview-data fallback
- sanitizer on input/output/save paths
- live overflow status and default save blocking
- cleanup of overflow scheduling/listeners and transient runtime state

## Fixtures

- `fixtures/data-tags/examlist-data-tags.json`: current grouped portable catalog with OPT1–OPT10
- `fixtures/templates/current-layout-template.json`: A4 cover/content template with safe area, page number, recognition marks, other-room setting, and OPT10 candidate grid

## Deliberate application boundary

The following current ExamList features remain in the consumer application or behind adapters:

- routes, navigation guards, account/school screens, permission UI
- `appState`, toast, modal orchestration, and busy overlay
- ExamList API clients and fixed API/asset paths
- XLSX operational data screens
- PDF queue, browser worker, file storage, and download flows
- full server preview renderer
- the high-level candidate-block controller/focus modal that coordinates application state

The portable package includes the current runtime and the reusable candidate-block core/DOM primitives, but does not copy application controllers that would require the ExamList state tree. Save, preview, upload, and URL resolution remain explicit consumer adapters.

## Verification coverage

- Node unit tests: source fingerprint, core, DOM, runtime import, fixtures, and normalization
- TypeScript public API compile test
- Playwright Chromium: multiple instances, CSS isolation, editing/upload, raw forwarding, multi-page state, current fixture page-switch/edit/save round trip, page settings, preview defaults, sanitizer, overflow blocking, and cleanup
- package dry run and installation of the actual generated `.tgz` into a clean temporary consumer

Browser tests live at `browser-tests/mount-template-editor.spec.js`.

The `npm run verify` workflow is intended for a source checkout used by maintainers or CI. Maintainer build/test scripts are not part of the installed-package contract.
