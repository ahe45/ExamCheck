export function getDocumentContentRoot(surface) {
  if (!surface) {
    return null;
  }

  return surface.querySelector(".template-doc") || surface;
}

function getDocumentContentRectBoundary(documentRoot) {
  const boundary = {
    bottom: 0,
    hasRect: false,
    left: Number.POSITIVE_INFINITY,
    right: 0,
    top: Number.POSITIVE_INFINITY,
  };

  function includeRect(rect) {
    if (!rect || (!rect.width && !rect.height)) {
      return;
    }

    boundary.bottom = Math.max(boundary.bottom, rect.bottom);
    boundary.hasRect = true;
    boundary.left = Math.min(boundary.left, rect.left);
    boundary.right = Math.max(boundary.right, rect.right);
    boundary.top = Math.min(boundary.top, rect.top);
  }

  const transientMeasurementSelector =
    ".template-editor-image-selection, .template-editor-image-resize-handle, .examlist-object-selection, .examlist-object-resize-handle, .template-editor-table-selection, .template-editor-table-handle, .template-editor-table-move-handle, .template-editor-table-select-handle, [data-candidate-block-grid-resize-handle], [data-candidate-block-grid-move-handle]";
  const candidateBlockGridMeasurementSelector = "[data-candidate-block-grid], .examlist-candidate-block-grid";
  const excludedTextMeasurementSelector = `${transientMeasurementSelector}, ${candidateBlockGridMeasurementSelector}`;
  const ownerDocument = documentRoot.ownerDocument || globalThis.document;
  const ownerWindow = ownerDocument?.defaultView || globalThis;
  const elementConstructor = ownerWindow.Element || globalThis.Element;
  const nodeTypes = ownerWindow.Node || globalThis.Node || { ELEMENT_NODE: 1, TEXT_NODE: 3 };

  // Cache only for this measurement: edits can change which paragraphs trail
  // visible content. Inspect each sibling list once, backwards, rather than
  // recursively rechecking every suffix (2^n work for n empty paragraphs).
  const measuredParents = new WeakSet();
  const emptyTrailingBlocks = new WeakSet();

  function isEmptyCaretContent(node) {
    if (node.nodeType === nodeTypes.TEXT_NODE) {
      return !String(node.textContent || "").replace(/[\u00a0\u200b\ufeff]/g, " ").trim();
    }
    if (node.nodeType !== nodeTypes.ELEMENT_NODE) return true;
    if (node.matches(".template-token, .template-generated-object, [data-template-tag-value], [contenteditable='false']")) {
      return false;
    }
    return node.matches("br, span, b, strong, i, em, u, s, strike, font") &&
      Array.from(node.childNodes).every(isEmptyCaretContent);
  }

  function isEmptyParagraph(element) {
    return element.matches("p") && Array.from(element.childNodes).every(isEmptyCaretContent);
  }

  function isEmptyTrailingBlockElement(element) {
    if (!(elementConstructor && element instanceof elementConstructor) || !element.matches("p")) {
      return false;
    }
    const parent = element.parentNode;
    if (!parent) return isEmptyParagraph(element);
    if (!measuredParents.has(parent)) {
      measuredParents.add(parent);
      let isTrailing = true;
      for (let node = parent.lastChild; node; node = node.previousSibling) {
        if (node.nodeType === nodeTypes.TEXT_NODE) {
          if (String(node.textContent || "").replace(/[\u00a0\u200b\ufeff]/g, " ").trim()) isTrailing = false;
          continue;
        }
        if (node.nodeType !== nodeTypes.ELEMENT_NODE) continue;
        if (node.matches("br") || node.matches(transientMeasurementSelector) || node.matches(candidateBlockGridMeasurementSelector)) {
          continue;
        }
        if (isTrailing && isEmptyParagraph(node)) emptyTrailingBlocks.add(node);
        else isTrailing = false;
      }
    }
    return emptyTrailingBlocks.has(element);
  }

  try {
    const nodeFilter = ownerWindow.NodeFilter || globalThis.NodeFilter;
    const range = ownerDocument.createRange();
    const textWalker = ownerDocument.createTreeWalker(documentRoot, nodeFilter.SHOW_TEXT, {
      acceptNode(textNode) {
        if (!String(textNode.textContent || "").replace(/[\u00a0\u200b\ufeff]/g, " ").trim()) {
          return nodeFilter.FILTER_REJECT;
        }

        return textNode.parentElement?.closest?.(excludedTextMeasurementSelector)
          ? nodeFilter.FILTER_REJECT
          : nodeFilter.FILTER_ACCEPT;
      },
    });

    while (textWalker.nextNode()) {
      range.selectNodeContents(textWalker.currentNode);
      Array.from(range.getClientRects()).forEach(includeRect);
    }

    range.detach?.();
  } catch (_error) {
    // Detached roots and test doubles use the element rectangles below.
  }

  documentRoot
    .querySelectorAll?.(
      "blockquote, figure, h1, h2, h3, hr, img, li, ol, p, table, ul, .template-generated-object, .template-token",
    )
    .forEach((element) => {
      if (element.closest(transientMeasurementSelector) || isEmptyTrailingBlockElement(element)) {
        return;
      }

      const candidateBlockGridElement = element.closest(candidateBlockGridMeasurementSelector);

      if (candidateBlockGridElement && candidateBlockGridElement !== element) {
        return;
      }

      Array.from(element.getClientRects?.() || []).forEach(includeRect);
    });

  if (!Number.isFinite(boundary.left)) {
    boundary.left = 0;
  }

  if (!Number.isFinite(boundary.top)) {
    boundary.top = 0;
  }

  return boundary;
}

export function getDocumentSurfaceOverflowInfo(surface) {
  if (!surface) {
    return { hasOverflow: false, heightOverflow: 0, widthOverflow: 0 };
  }

  const documentRoot = getDocumentContentRoot(surface);

  if (documentRoot && typeof documentRoot.getBoundingClientRect === "function") {
    const rootRect = documentRoot.getBoundingClientRect();
    const contentBoundary = getDocumentContentRectBoundary(documentRoot);
    const heightOverflow = contentBoundary.hasRect
      ? Math.max(0, Math.ceil(contentBoundary.bottom - rootRect.bottom))
      : 0;
    const widthOverflow = contentBoundary.hasRect
      ? Math.max(
          Math.max(0, Math.ceil(rootRect.left - contentBoundary.left)),
          Math.max(0, Math.ceil(contentBoundary.right - rootRect.right)),
        )
      : 0;

    return {
      hasOverflow: heightOverflow > 4 || widthOverflow > 4,
      heightOverflow,
      widthOverflow,
    };
  }

  const surfaceHeightOverflow = Math.max(0, Math.ceil(surface.scrollHeight - surface.clientHeight));
  const surfaceWidthOverflow = Math.max(0, Math.ceil(surface.scrollWidth - surface.clientWidth));
  const rootHeightOverflow = documentRoot ? Math.max(0, Math.ceil(documentRoot.scrollHeight - documentRoot.clientHeight)) : 0;
  const rootWidthOverflow = documentRoot ? Math.max(0, Math.ceil(documentRoot.scrollWidth - documentRoot.clientWidth)) : 0;
  const heightOverflow = Math.max(surfaceHeightOverflow, rootHeightOverflow);
  const widthOverflow = Math.max(surfaceWidthOverflow, rootWidthOverflow);

  return {
    hasOverflow: heightOverflow > 4 || widthOverflow > 4,
    heightOverflow,
    widthOverflow,
  };
}

export function getDocumentOverflowMessage(overflowInfo) {
  if (!overflowInfo?.hasOverflow) {
    return "";
  }

  const details = [
    overflowInfo.heightOverflow > 4 ? `세로 ${overflowInfo.heightOverflow}px` : "",
    overflowInfo.widthOverflow > 4 ? `가로 ${overflowInfo.widthOverflow}px` : "",
  ].filter(Boolean);

  return `A4 용지 영역을 초과했습니다${details.length ? ` (${details.join(", ")})` : ""}. 초과된 내용은 저장할 수 없습니다.`;
}
