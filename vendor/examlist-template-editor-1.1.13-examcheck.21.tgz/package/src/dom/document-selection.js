// Bookmark only the editable DOM. Flow spacers and selection overlays are
// rebuilt during canonicalization and must not shift text-node paths.
const transientSelector = '[data-template-object-flow-spacer], .template-editor-table-selection, .template-editor-image-selection, [data-candidate-block-grid-resize-handle], [data-candidate-block-grid-move-handle]';
const children = node => Array.from(node.childNodes).filter(child => !child.matches?.(transientSelector));

export function captureDocumentSelection(root) {
  const selection = root?.ownerDocument.defaultView?.getSelection();
  if (!selection?.rangeCount) return null;
  const range = selection.getRangeAt(0);
  if (!root.contains(range.startContainer) || !root.contains(range.endContainer)) return null;
  const boundary = (node, offset) => {
    const path = [];
    const content = node.nodeType === 3 ? node.textContent : null;
    const normalizedOffset = node.nodeType === 3 ? offset : children(node).filter(child => Array.prototype.indexOf.call(node.childNodes, child) < offset).length;
    while (node !== root) {
      const parent = node.parentNode;
      const index = children(parent).indexOf(node);
      if (index < 0) return null;
      path.unshift(index);
      node = parent;
    }
    return { path, offset: normalizedOffset, content };
  };
  const start = boundary(range.startContainer, range.startOffset);
  const end = boundary(range.endContainer, range.endOffset);
  return start && end ? { start, end, backward: selection.anchorNode === range.endContainer && selection.anchorOffset === range.endOffset } : null;
}

export function restoreDocumentSelection(root, bookmark) {
  if (!root?.isConnected || !bookmark) return null;
  const resolve = point => {
    let node = root;
    for (const index of point.path) {
      node = children(node)[index];
      if (!node) return null;
    }
    if (point.content !== null) {
      if (node.nodeType !== 3 || node.textContent !== point.content) return null;
      return { node, offset: Math.min(point.offset, node.length) };
    }
    const child = children(node)[point.offset];
    return { node, offset: child ? Array.prototype.indexOf.call(node.childNodes, child) : node.childNodes.length };
  };
  const start = resolve(bookmark.start), end = resolve(bookmark.end);
  const selection = root.ownerDocument.defaultView?.getSelection();
  if (!start || !end || !selection) return null;
  const range = root.ownerDocument.createRange();
  range.setStart(start.node, start.offset);
  range.setEnd(end.node, end.offset);
  if (bookmark.backward && !range.collapsed) {
    selection.setBaseAndExtent(end.node, end.offset, start.node, start.offset);
  } else {
    selection.removeAllRanges();
    selection.addRange(range);
  }
  return range;
}
