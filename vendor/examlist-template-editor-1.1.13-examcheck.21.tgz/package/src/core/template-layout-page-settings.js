import {
  normalizeCandidateBlockGridSortDirection,
  normalizeCandidateBlockGridSortKey,
} from "./candidate-block-grid-config.js";

export const supportedPageNumberPresets = Object.freeze([
  "numericCurrentTotal",
  "pageCurrentTotal",
  "pageCurrentTotalEnglish",
  "currentPageKorean",
  "koreanPage",
  "currentPageOfTotalKorean",
  "koreanPageOfTotal",
]);

export const supportedPageNumberPositions = Object.freeze(["left", "center", "right"]);

const legacyPageNumberPresetAliases = Object.freeze({
  current: "currentPageKorean",
  currentTotal: "numericCurrentTotal",
});

function normalizeBoolean(value, fallback = true) {
  if (typeof value === "boolean") {
    return value;
  }

  if (typeof value === "number") {
    return value !== 0;
  }

  const normalizedValue = String(value || "").trim().toLowerCase();

  if (!normalizedValue) {
    return fallback;
  }

  if (["true", "1", "yes"].includes(normalizedValue)) {
    return true;
  }

  if (["false", "0", "no"].includes(normalizedValue)) {
    return false;
  }

  return fallback;
}

function normalizeFiniteNumber(value, fallback, minimum = 0, maximum = 100000) {
  const parsedValue = Number(value);

  if (!Number.isFinite(parsedValue)) {
    return fallback;
  }

  return Math.min(Math.max(parsedValue, minimum), maximum);
}

function normalizeMargin(margin, fallbackMargin) {
  const source = margin && typeof margin === "object" ? margin : {};
  const fallback = fallbackMargin && typeof fallbackMargin === "object" ? fallbackMargin : {};

  return {
    top: normalizeFiniteNumber(source.top, normalizeFiniteNumber(fallback.top, 0, 0), 0),
    right: normalizeFiniteNumber(source.right, normalizeFiniteNumber(fallback.right, 0, 0), 0),
    bottom: normalizeFiniteNumber(source.bottom, normalizeFiniteNumber(fallback.bottom, 0, 0), 0),
    left: normalizeFiniteNumber(source.left, normalizeFiniteNumber(fallback.left, 0, 0), 0),
  };
}

export function normalizeRecognitionMarks(settings) {
  const source = settings && typeof settings === "object" ? settings : {};

  return {
    enabled: source.enabled === true || String(source.enabled || "").trim().toLowerCase() === "true",
    offsetXPt: normalizeFiniteNumber(source.offsetXPt ?? source.xPt ?? source.offsetX ?? source.x, 14.17, 0, 240),
    offsetYPt: normalizeFiniteNumber(source.offsetYPt ?? source.yPt ?? source.offsetY ?? source.y, 14.17, 0, 240),
    sizePt: normalizeFiniteNumber(source.sizePt ?? source.size, 11.34, 2, 72),
  };
}

export function normalizePageNumberSettings(settings) {
  const source = settings && typeof settings === "object" ? settings : {};
  const rawPreset = String(source.preset || "").trim();
  const preset = supportedPageNumberPresets.includes(rawPreset)
    ? rawPreset
    : legacyPageNumberPresetAliases[rawPreset] || "numericCurrentTotal";
  const rawPosition = String(source.position || source.align || source.textAlign || "").trim();
  const position = supportedPageNumberPositions.includes(rawPosition) ? rawPosition : "center";

  return {
    enabled: normalizeBoolean(source.enabled, false),
    position,
    preset,
  };
}

export function normalizeOtherRoomPageSettings(settings) {
  const source = settings && typeof settings === "object" ? settings : {};

  return {
    enabled: normalizeBoolean(source.enabled, false),
  };
}

export function isCoverPageType(value) {
  return String(value || "").trim() === "cover";
}

export function isSmokeCandidateBlockTemplateHtml(value) {
  const normalizedText = String(value || "")
    .replace(/<br\s*\/?>/gi, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .trim();

  return normalizedText === "공통 블록";
}

function normalizeCandidateBlockTemplateHtml(value) {
  const rawValue = String(value || "").trim();

  return isSmokeCandidateBlockTemplateHtml(rawValue) ? "<p><br></p>" : rawValue || "<p><br></p>";
}

function normalizeCandidateBlockTemplateFeature(value) {
  const source = value && typeof value === "object" ? value : {};

  return {
    enabled: normalizeBoolean(source.enabled, false),
    templateHtml: normalizeCandidateBlockTemplateHtml(source.templateHtml ?? source.blockTemplateHtml),
  };
}

function getCandidateBlockSortNormalizers(normalizers) {
  const source = normalizers && typeof normalizers === "object" ? normalizers : {};
  const sortKeyNormalizer = source.normalizeSortKey || source.normalizeCandidateBlockGridSortKey;
  const sortDirectionNormalizer = source.normalizeSortDirection
    || source.normalizeCandidateBlockGridSortDirection;

  return {
    normalizeSortDirection: typeof sortDirectionNormalizer === "function"
      ? sortDirectionNormalizer
      : normalizeCandidateBlockGridSortDirection,
    normalizeSortKey: typeof sortKeyNormalizer === "function"
      ? sortKeyNormalizer
      : normalizeCandidateBlockGridSortKey,
  };
}

export function normalizeCandidateBlockGridSettings(settings, normalizers = {}) {
  const source = settings && typeof settings === "object" ? settings : {};
  const blockTemplateHtml = normalizeCandidateBlockTemplateHtml(source.blockTemplateHtml);
  const columnNameRowSource = source.columnNameRow ?? source.fieldNameRow;
  const columnNameRow = normalizeCandidateBlockTemplateFeature(columnNameRowSource);
  const { normalizeSortDirection, normalizeSortKey } = getCandidateBlockSortNormalizers(normalizers);

  return {
    blockTemplateHtml,
    columnNameRow: {
      ...columnNameRow,
      heightPt: normalizeFiniteNumber(
        columnNameRowSource?.heightPt ?? columnNameRowSource?.height,
        20,
        4,
        240,
      ),
    },
    columns: Math.round(normalizeFiniteNumber(source.columns, 2, 1, 4)),
    enabled: normalizeBoolean(source.enabled, false),
    emptyBlockLayer: normalizeCandidateBlockTemplateFeature(source.emptyBlockLayer ?? source.emptyValueLayer),
    fillEmptyBlocks: normalizeBoolean(source.fillEmptyBlocks, true),
    gapXPt: normalizeFiniteNumber(source.gapXPt ?? source.gapX, 4, 0, 48),
    gapYPt: normalizeFiniteNumber(source.gapYPt ?? source.gapY, 4, 0, 48),
    heightPt: normalizeFiniteNumber(source.heightPt, 0, 0, 2000),
    rows: Math.round(normalizeFiniteNumber(source.rows, 10, 1, 30)),
    sortDirection: normalizeSortDirection(source.sortDirection ?? source.sort?.direction),
    sortKey: normalizeSortKey(source.sortKey ?? source.sortField ?? source.sort?.field),
    variant: "photo",
    widthPt: normalizeFiniteNumber(source.widthPt, 0, 0, 2000),
    xPt: normalizeFiniteNumber(source.xPt ?? source.x, 0, 0, 2000),
    yPt: normalizeFiniteNumber(source.yPt ?? source.y, 0, 0, 2000),
  };
}

export function normalizePageSettings(
  settings,
  paperConfig,
  pageType = "",
  candidateBlockGridNormalizers = {},
) {
  const normalizedSettings = settings && typeof settings === "object" ? { ...settings } : {};

  normalizedSettings.safeArea = normalizeMargin(normalizedSettings.safeArea, paperConfig?.margin);

  if (normalizedSettings.recognitionMarks && typeof normalizedSettings.recognitionMarks === "object") {
    normalizedSettings.recognitionMarks = normalizeRecognitionMarks(normalizedSettings.recognitionMarks);
  }

  if (normalizedSettings.pageNumber && typeof normalizedSettings.pageNumber === "object") {
    normalizedSettings.pageNumber = normalizePageNumberSettings(normalizedSettings.pageNumber);

    if (isCoverPageType(pageType)) {
      normalizedSettings.pageNumber.enabled = false;
    }
  }

  if (normalizedSettings.candidateBlockGrid && typeof normalizedSettings.candidateBlockGrid === "object") {
    normalizedSettings.candidateBlockGrid = normalizeCandidateBlockGridSettings(
      normalizedSettings.candidateBlockGrid,
      candidateBlockGridNormalizers,
    );

    if (isCoverPageType(pageType)) {
      normalizedSettings.candidateBlockGrid.enabled = false;
    }
  }

  if (normalizedSettings.otherRoomPage && typeof normalizedSettings.otherRoomPage === "object") {
    normalizedSettings.otherRoomPage = normalizeOtherRoomPageSettings(normalizedSettings.otherRoomPage);

    if (isCoverPageType(pageType)) {
      normalizedSettings.otherRoomPage.enabled = false;
    }
  }

  return normalizedSettings;
}
