export const dataTagViewOptionsEventName = "examlist:data-tag-view-options-change";

export const defaultDataTagViewOptions = Object.freeze({
  showIcons: false,
  showSampleData: true,
});

function normalizeBoolean(value, fallback) {
  return typeof value === "boolean" ? value : fallback;
}

export function normalizeDataTagViewOptions(options = {}) {
  const source = options && typeof options === "object" && !Array.isArray(options) ? options : {};

  return Object.freeze({
    showIcons: normalizeBoolean(source.showIcons, defaultDataTagViewOptions.showIcons),
    showSampleData: normalizeBoolean(source.showSampleData, defaultDataTagViewOptions.showSampleData),
  });
}
