const pointsPerMillimeter = 72 / 25.4;
const millimetersPerPoint = 25.4 / 72;
const defaultSafeAreaPt = Object.freeze({
  bottom: 28.35,
  left: 28.35,
  right: 28.35,
  top: 28.35,
});

export const supportedRuntimePageSizes = new Set(["A3", "A4", "B5", "LETTER", "LEGAL"]);

export const examListPaperPresetByRuntimeSize = Object.freeze({
  A3: "A3",
  A4: "A4",
  B5: "B5",
  LEGAL: "Legal",
  LETTER: "Letter",
});

export const runtimePageSizeByExamListPaperPreset = Object.freeze({
  A3: "A3",
  A4: "A4",
  B5: "B5",
  Legal: "LEGAL",
  Letter: "LETTER",
});

export const paperPresetDimensionsPt = Object.freeze({
  A3: Object.freeze({ heightPt: 1190.55, widthPt: 841.89 }),
  A4: Object.freeze({ heightPt: 841.89, widthPt: 595.28 }),
  B5: Object.freeze({ heightPt: 728.5, widthPt: 515.91 }),
  Legal: Object.freeze({ heightPt: 1008, widthPt: 612 }),
  Letter: Object.freeze({ heightPt: 792, widthPt: 612 }),
});

export function toFiniteNumber(value, fallback = 0) {
  const numericValue = Number(value);

  return Number.isFinite(numericValue) ? numericValue : fallback;
}

export function toMillimeterValue(pointValue) {
  return Math.max(0, Math.round(toFiniteNumber(pointValue, 0) * millimetersPerPoint * 10) / 10);
}

export function toPointValue(millimeterValue) {
  return Math.max(0, Math.round(toFiniteNumber(millimeterValue, 0) * pointsPerMillimeter * 100) / 100);
}

export function normalizeOrientation(value) {
  return String(value || "").trim() === "landscape" ? "landscape" : "portrait";
}

export function getRuntimePageSizeFromTemplate(template) {
  return runtimePageSizeByExamListPaperPreset[template?.paperPreset] || "A4";
}

export function getSafeAreaPt(page, template) {
  const pageSafeArea = page?.settings?.safeArea && typeof page.settings.safeArea === "object"
    ? page.settings.safeArea
    : {};
  const templateMargin = template?.layout?.paper?.margin && typeof template.layout.paper.margin === "object"
    ? template.layout.paper.margin
    : defaultSafeAreaPt;

  return {
    bottom: toFiniteNumber(pageSafeArea.bottom, toFiniteNumber(templateMargin.bottom, defaultSafeAreaPt.bottom)),
    left: toFiniteNumber(pageSafeArea.left, toFiniteNumber(templateMargin.left, defaultSafeAreaPt.left)),
    right: toFiniteNumber(pageSafeArea.right, toFiniteNumber(templateMargin.right, defaultSafeAreaPt.right)),
    top: toFiniteNumber(pageSafeArea.top, toFiniteNumber(templateMargin.top, defaultSafeAreaPt.top)),
  };
}

export function getRuntimePageSettings(page, template) {
  const safeArea = getSafeAreaPt(page, template);

  return {
    marginBottom: toMillimeterValue(safeArea.bottom),
    marginLeft: toMillimeterValue(safeArea.left),
    marginRight: toMillimeterValue(safeArea.right),
    marginTop: toMillimeterValue(safeArea.top),
    orientation: normalizeOrientation(template?.orientation),
    size: getRuntimePageSizeFromTemplate(template),
  };
}

function decodeHtmlAttribute(value = "") {
  return String(value || "")
    .replaceAll("&quot;", '"')
    .replaceAll("&#39;", "'")
    .replaceAll("&gt;", ">")
    .replaceAll("&lt;", "<")
    .replaceAll("&amp;", "&");
}

function escapeHtmlAttribute(value = "") {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function getAttributeValueFromTag(tagMarkup = "", attributeName = "") {
  const escapedName = String(attributeName || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const matcher = new RegExp(`\\s${escapedName}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s>]+))`, "i");
  const [, , doubleQuoted = "", singleQuoted = "", unquoted = ""] = String(tagMarkup || "").match(matcher) || [];

  return decodeHtmlAttribute(doubleQuoted || singleQuoted || unquoted || "");
}

function findTemplateDocumentStartTag(markup = "") {
  const tagMatcher = /<[^>]+>/g;
  const sourceMarkup = String(markup || "");
  let tagMatch = tagMatcher.exec(sourceMarkup);

  while (tagMatch) {
    const classNames = getAttributeValueFromTag(tagMatch[0], "class").split(/\s+/).filter(Boolean);

    if (classNames.includes("template-doc")) {
      return {
        end: tagMatcher.lastIndex,
        start: tagMatch.index,
        tag: tagMatch[0],
      };
    }

    tagMatch = tagMatcher.exec(sourceMarkup);
  }

  return null;
}

function upsertTagAttribute(tagMarkup, attributeName, value) {
  const escapedName = String(attributeName || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const matcher = new RegExp(`(\\s${escapedName}\\s*=\\s*)("[^"]*"|'[^']*'|[^\\s>]+)`, "i");
  const serializedValue = `"${escapeHtmlAttribute(value)}"`;

  if (matcher.test(tagMarkup)) {
    return tagMarkup.replace(matcher, `$1${serializedValue}`);
  }

  return tagMarkup.replace(/\s*\/?>(\s*)$/, (closing) => ` ${attributeName}=${serializedValue}${closing}`);
}

export function readRuntimePageSettingsFromHtml(html) {
  const startTag = findTemplateDocumentStartTag(html)?.tag || "";

  return {
    marginBottom: toFiniteNumber(getAttributeValueFromTag(startTag, "data-template-page-margin-bottom"), 10),
    marginLeft: toFiniteNumber(getAttributeValueFromTag(startTag, "data-template-page-margin-left"), 10),
    marginRight: toFiniteNumber(getAttributeValueFromTag(startTag, "data-template-page-margin-right"), 10),
    marginTop: toFiniteNumber(getAttributeValueFromTag(startTag, "data-template-page-margin-top"), 10),
    orientation: normalizeOrientation(getAttributeValueFromTag(startTag, "data-template-page-orientation")),
    size: String(getAttributeValueFromTag(startTag, "data-template-page-size") || "A4").trim().toUpperCase() || "A4",
  };
}

export function writeRuntimePageSettingsToHtml(html, rawSettings = {}) {
  const settings = {
    marginBottom: toFiniteNumber(rawSettings.marginBottom, 10),
    marginLeft: toFiniteNumber(rawSettings.marginLeft, 10),
    marginRight: toFiniteNumber(rawSettings.marginRight, 10),
    marginTop: toFiniteNumber(rawSettings.marginTop, 10),
    orientation: normalizeOrientation(rawSettings.orientation),
    size: String(rawSettings.size || "A4").trim().toUpperCase() || "A4",
  };
  const attributes = {
    "data-template-page-margin-bottom": settings.marginBottom,
    "data-template-page-margin-left": settings.marginLeft,
    "data-template-page-margin-right": settings.marginRight,
    "data-template-page-margin-top": settings.marginTop,
    "data-template-page-orientation": settings.orientation,
    "data-template-page-size": settings.size,
  };
  let sourceHtml = String(html || "").trim();
  let startTag = findTemplateDocumentStartTag(sourceHtml);

  if (!startTag) {
    sourceHtml = `<div class="template-doc">${sourceHtml || "<p><br></p>"}</div>`;
    startTag = findTemplateDocumentStartTag(sourceHtml);
  }

  let nextTag = startTag.tag;

  Object.entries(attributes).forEach(([name, value]) => {
    nextTag = upsertTagAttribute(nextTag, name, String(value));
  });

  return `${sourceHtml.slice(0, startTag.start)}${nextTag}${sourceHtml.slice(startTag.end)}`;
}

export function applyPaperSettingsToTemplate(template, settings, initialPaperPreset = "") {
  const nextPaperPreset = examListPaperPresetByRuntimeSize[settings.size];
  const canApplyRuntimePaperPreset =
    nextPaperPreset &&
    supportedRuntimePageSizes.has(settings.size) &&
    Boolean(runtimePageSizeByExamListPaperPreset[initialPaperPreset]);

  if (!template || !canApplyRuntimePaperPreset) {
    return false;
  }

  const baseDimension = paperPresetDimensionsPt[nextPaperPreset] || paperPresetDimensionsPt.A4;
  const orientation = normalizeOrientation(settings.orientation);
  const widthPt = orientation === "landscape" ? baseDimension.heightPt : baseDimension.widthPt;
  const heightPt = orientation === "landscape" ? baseDimension.widthPt : baseDimension.heightPt;

  template.paperPreset = nextPaperPreset;
  template.orientation = orientation;

  if (template.layout?.paper) {
    template.layout.paper = {
      ...template.layout.paper,
      heightPt,
      orientation,
      preset: nextPaperPreset,
      widthPt,
    };
  }

  if (Array.isArray(template.layout?.pages)) {
    template.layout.pages = template.layout.pages.map((page) => ({ ...page, heightPt, widthPt }));
  }

  return true;
}

export function applySafeAreaToTemplate(template, selectedPage, settings) {
  if (!template || !selectedPage) {
    return false;
  }

  const safeArea = {
    bottom: toPointValue(settings.marginBottom),
    left: toPointValue(settings.marginLeft),
    right: toPointValue(settings.marginRight),
    top: toPointValue(settings.marginTop),
  };

  selectedPage.settings = { ...(selectedPage.settings || {}), safeArea };

  if (template.layout?.paper) {
    template.layout.paper = { ...template.layout.paper, margin: safeArea };
  }

  return true;
}

function getTemplatePage(template, pageId = "") {
  const pages = Array.isArray(template?.layout?.pages) ? template.layout.pages : [];
  const normalizedPageId = String(pageId || "").trim();

  return (normalizedPageId ? pages.find((page) => String(page?.id || "") === normalizedPageId) : null) || pages[0] || null;
}

export function prepareTemplatePageHtml(template, pageId = "", html = "") {
  const page = getTemplatePage(template, pageId);

  return writeRuntimePageSettingsToHtml(html, getRuntimePageSettings(page, template));
}

export function syncTemplatePageSettingsFromHtml(template, pageId = "", html = "", initialPaperPreset = "") {
  const page = getTemplatePage(template, pageId);

  if (!page) {
    return template;
  }

  const settings = readRuntimePageSettingsFromHtml(html);

  page.settings = {
    ...(page.settings || {}),
    documentHtml: String(html || ""),
    editorMode: "document",
  };
  applySafeAreaToTemplate(template, page, settings);
  applyPaperSettingsToTemplate(template, settings, initialPaperPreset || template.paperPreset || "");
  return template;
}
