import { generatedObjectPreviewValues } from "./generated-objects-config.js";
import { getGeneratedObjectSourceOptions } from "./generated-objects-source.js";

export const generatedObjectPreviewPhotoDefaults = Object.freeze({
  fileId: "sample-candidate-photo.png",
  url: "",
});

function normalizePreviewOptions(options = {}) {
  const source = options && typeof options === "object" && !Array.isArray(options) ? options : {};
  const currentDate = String(source.currentDate || new Date().toISOString().slice(0, 10)).trim();

  return {
    currentDate,
    hasPhoto: source.hasPhoto !== false,
    photoFileId: String(source.photoFileId ?? generatedObjectPreviewPhotoDefaults.fileId),
    photoUrl: String(source.photoUrl ?? generatedObjectPreviewPhotoDefaults.url),
    useTemplatePreviewPhoto: source.useTemplatePreviewPhoto !== false,
  };
}

export function buildGeneratedObjectPreviewData(tagDefinitions = [], options = {}) {
  const previewOptions = normalizePreviewOptions(options);
  const flatValues = getGeneratedObjectSourceOptions(tagDefinitions).reduce((values, option) => {
    values[option.key] = String(option.example || generatedObjectPreviewValues[option.key] || "").trim();
    return values;
  }, {});

  return {
    ...flatValues,
    "candidate.photoFileId": previewOptions.photoFileId,
    "candidate.photoUrl": previewOptions.photoUrl,
    admission: generatedObjectPreviewValues["candidate.admissionTypeName"],
    admissionYear: generatedObjectPreviewValues["candidate.admissionYear"],
    birth: generatedObjectPreviewValues["candidate.birthDate"],
    building: generatedObjectPreviewValues["candidate.buildingName"],
    campus: generatedObjectPreviewValues["candidate.campusName"],
    candidate: {
      admissionRoundName: generatedObjectPreviewValues["candidate.admissionRoundName"],
      admissionTypeCode: generatedObjectPreviewValues["candidate.admissionTypeCode"],
      admissionTypeName: generatedObjectPreviewValues["candidate.admissionTypeName"],
      applicationNo: generatedObjectPreviewValues["candidate.applicationNo"],
      admissionYear: generatedObjectPreviewValues["candidate.admissionYear"],
      birthDate: generatedObjectPreviewValues["candidate.birthDate"],
      buildingCode: generatedObjectPreviewValues["candidate.buildingCode"],
      buildingName: generatedObjectPreviewValues["candidate.buildingName"],
      campusCode: generatedObjectPreviewValues["candidate.campusCode"],
      campusName: generatedObjectPreviewValues["candidate.campusName"],
      departmentCode: generatedObjectPreviewValues["candidate.departmentCode"],
      departmentName: generatedObjectPreviewValues["candidate.departmentName"],
      designatedSort: generatedObjectPreviewValues["candidate.designatedSort"],
      examDate: generatedObjectPreviewValues["candidate.examDate"],
      examEndTime: generatedObjectPreviewValues["candidate.examEndTime"],
      examName: generatedObjectPreviewValues["candidate.examName"],
      examNo: generatedObjectPreviewValues["candidate.examNo"],
      examStartTime: generatedObjectPreviewValues["candidate.examStartTime"],
      groupName: generatedObjectPreviewValues["candidate.groupName"],
      majorCode: generatedObjectPreviewValues["candidate.majorCode"],
      majorName: generatedObjectPreviewValues["candidate.majorName"],
      name: generatedObjectPreviewValues["candidate.name"],
      opt1: generatedObjectPreviewValues["candidate.opt1"],
      opt2: generatedObjectPreviewValues["candidate.opt2"],
      opt3: generatedObjectPreviewValues["candidate.opt3"],
      opt4: generatedObjectPreviewValues["candidate.opt4"],
      opt5: generatedObjectPreviewValues["candidate.opt5"],
      opt6: generatedObjectPreviewValues["candidate.opt6"],
      opt7: generatedObjectPreviewValues["candidate.opt7"],
      opt8: generatedObjectPreviewValues["candidate.opt8"],
      opt9: generatedObjectPreviewValues["candidate.opt9"],
      opt10: generatedObjectPreviewValues["candidate.opt10"],
      periodCode: generatedObjectPreviewValues["candidate.periodCode"],
      periodName: generatedObjectPreviewValues["candidate.periodName"],
      photo: generatedObjectPreviewValues["candidate.photo"],
      photoFileId: previewOptions.photoFileId,
      photoUrl: previewOptions.photoUrl,
      roomId: generatedObjectPreviewValues["candidate.roomId"],
      roomCode: generatedObjectPreviewValues["candidate.roomCode"],
      roomName: generatedObjectPreviewValues["candidate.roomName"],
      seriesCode: generatedObjectPreviewValues["candidate.seriesCode"],
      seriesName: generatedObjectPreviewValues["candidate.seriesName"],
      temporaryNo: generatedObjectPreviewValues["candidate.temporaryNo"],
    },
    currentDate: previewOptions.currentDate,
    exam: generatedObjectPreviewValues["candidate.examName"],
    endTime: generatedObjectPreviewValues["candidate.examEndTime"],
    examEndTime: generatedObjectPreviewValues["candidate.examEndTime"],
    examNo: generatedObjectPreviewValues["candidate.examNo"],
    examineeNo: generatedObjectPreviewValues["candidate.examNo"],
    hasPhoto: previewOptions.hasPhoto,
    group: generatedObjectPreviewValues["candidate.groupName"],
    major: generatedObjectPreviewValues["candidate.majorName"],
    name: generatedObjectPreviewValues["candidate.name"],
    period: generatedObjectPreviewValues["candidate.periodName"],
    photoFileId: previewOptions.photoFileId,
    photoUrl: previewOptions.photoUrl,
    room: generatedObjectPreviewValues["candidate.roomName"],
    assignedCount: generatedObjectPreviewValues["room.assignedCount"],
    school: {
      academicYear: generatedObjectPreviewValues["school.academicYear"],
      code: generatedObjectPreviewValues["school.code"],
      name: generatedObjectPreviewValues["school.name"],
      schoolCode: generatedObjectPreviewValues["school.code"],
    },
    series: generatedObjectPreviewValues["candidate.seriesName"],
    session: generatedObjectPreviewValues["candidate.examStartTime"],
    time: generatedObjectPreviewValues["candidate.examStartTime"],
    track: generatedObjectPreviewValues["candidate.examName"],
    unit: generatedObjectPreviewValues["candidate.departmentName"],
    useTemplatePreviewPhoto: previewOptions.useTemplatePreviewPhoto,
  };
}
