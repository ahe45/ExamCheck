# ExamList Template Editor

ExamList에서 사용하는 양식 편집기 기능을 다른 프로젝트에 설치할 수 있도록 분리한 ESM 패키지입니다. `v1.1.0`은 현재 ExamList 기준의 브라우저 runtime과 scoped CSS뿐 아니라 다중 페이지 상태, 페이지 설정, 후보 블록 OPT10, 생성 객체, 문서 sanitizer, overflow 저장 차단, 재사용 가능한 core/DOM 계산 모듈을 함께 제공합니다.

## 설치

운영 프로젝트에서는 변경되지 않는 tag를 고정해서 설치합니다.

```bash
npm install github:ahe45/template-editor#v1.1.0
```

비공개 저장소를 SSH로 설치하는 경우:

```bash
npm install git+ssh://git@github.com/ahe45/template-editor.git#v1.1.0
```

## 빠른 적용

```js
import { mountTemplateEditor } from "examlist-template-editor";
import "examlist-template-editor/styles.css";

const editor = mountTemplateEditor({
  root: document.getElementById("editor"),
  template,
  selectedPageId: "content-page",
  dataTags,
  adapters: {
    saveTemplate: async ({ template }) => {
      await saveTemplateToYourApi(template);
      return template;
    },
    previewPdf: ({ template, html, sampleData }) =>
      previewTemplateWithYourApi({ template, html, sampleData }),
    uploadImage: async ({ file }) => ({
      url: await uploadFileToYourServer(file),
      alt: file.name,
    }),
    buildApiUrl: (path) => new URL(path, location.origin).href,
  },
  onChange(nextTemplate, { html, selectedPageId }) {
    updateLocalState(nextTemplate, { html, selectedPageId });
  },
  onOverflowChange(info, message) {
    showOverflowWarning(info.hasOverflow ? message : "");
  },
});

await editor.preview();
await editor.save();

// 화면을 제거하기 전에 반드시 정리합니다.
editor.destroy();
```

`mountTemplateEditor()`는 브라우저 DOM이 필요합니다. 패키지와 `core`/`dom` entry는 Node.js에서도 안전하게 import할 수 있지만, 편집기 mount와 실제 DOM 조작 함수는 브라우저에서 호출해야 합니다.

## v1.1.0 적용 범위

- 현재 runtime manifest의 91개 스크립트를 순서대로 생성한 ESM bundle
- 현재 양식 편집기 CSS 전체와 페이지 번호 하단 여백 19px 수정
- 데스크톱 4열 기본 레이아웃과 명시적 responsive 레이아웃
- 다중 페이지 선택·전환·페이지별 HTML 저장
- A3/A4/B5/Letter/Legal, 방향, safe area의 runtime ↔ template 동기화
- 페이지 번호, 인식 마크, 타 고사실, 후보 블록 서버 설정 정규화
- 후보 블록 정렬 키 OPT1부터 OPT10까지와 legacy alias
- 후보 블록 geometry, boundary, keyboard, table layout/normalizer 유틸
- 데이터 태그 그룹·기본 정의·보기 옵션과 날짜/시간 포맷
- generation unit 우선순위 설정
- Code128, QR, 생성 객체 source/preview/SVG/markup
- 문서 token, image geometry, table segment, object-flow 호환 유틸
- 저장 HTML sanitizer와 transient 편집 상태 제거
- 문서 영역 overflow 감지 및 기본 저장 차단
- TypeScript 공개 선언, 현재 template/data-tag fixture
- 원본 runtime/CSS source fingerprint와 stale artifact 검사

ExamList route, 계정/학교 권한 화면, 앱 전역 상태, toast/busy UI, API client, XLSX 운영 화면, PDF worker는 패키지에 넣지 않습니다. 저장·미리보기·업로드·URL 생성은 소비 프로젝트의 adapter가 담당합니다.

## 편집기 API

주요 반환 메서드는 다음과 같습니다.

- 값: `getValue()`, `setValue()`, `getHtml()`, `setHtml()`, `sync()`
- 페이지: `getSelectedPageId()`, `setSelectedPage()`
- 상태: `isDirty()`, `getOverflowInfo()`, `setReadOnly()`
- 작업: `preview()`, `save()`, `focus()`, `destroy()`
- 편집: `insertHtml()`, `insertTag()`, `insertImage()`, `undo()`, `redo()`
- 고급 runtime: `state`, `getRuntime()`, selection/overlay/render 전달 메서드

원본 runtime API가 필요한 경우 named export도 사용할 수 있습니다.

```js
import { createTemplateEditor } from "examlist-template-editor/runtime";

const rawEditor = createTemplateEditor({
  root,
  toolbarHost,
  surface,
  tagHost,
  pagePropertiesHost,
});
```

## 다중 페이지

```js
editor.setSelectedPage("page-2");

editor.setValue(nextTemplate, {
  selectedPageId: "page-3",
  markClean: true,
});
```

페이지를 바꿀 때 현재 페이지 HTML을 먼저 template에 반영하고 다음 페이지의 `settings.documentHtml`을 불러옵니다. `onChange` context에는 실제 `selectedPageId`가 전달됩니다.

## HTML 안전 처리와 overflow

초기 HTML, `setHtml()`, 변경 callback, 조회·미리보기·저장 값은 기본적으로 sanitizer를 통과합니다. `<script>`, inline event handler, 위험한 이미지 URL, 허용되지 않은 속성·스타일, 선택 overlay 같은 transient 상태가 제거됩니다.

`save()` 직전에는 현재 문서 영역을 다시 측정합니다. 세로 또는 가로 overflow가 4px보다 크면 `code === "TEMPLATE_EDITOR_OVERFLOW"`인 오류를 던지고 adapter를 호출하지 않습니다.

```js
try {
  await editor.save();
} catch (error) {
  if (error.code === "TEMPLATE_EDITOR_OVERFLOW") {
    console.warn(error.message, error.overflow);
  }
}
```

신뢰할 수 있는 HTML을 별도 정책으로 처리하는 프로젝트만 `sanitizeHtml: false`를 사용할 수 있습니다. 저장 차단을 소비 프로젝트가 직접 처리할 때는 `blockSaveOnOverflow: false`를 명시합니다.

## Core와 DOM entry

브라우저 UI 없이 정규화·계산·SVG 생성만 사용할 수 있습니다.

```js
import {
  buildGeneratedObjectMarkup,
  formatDataTagSampleValue,
  normalizeCandidateBlockGridConfig,
  normalizePageSettings,
} from "examlist-template-editor/core";

const formatted = formatDataTagSampleValue(
  "candidate.examDate",
  "2026-11-28",
  "YYYY.MM.DD (ddd)",
);

const grid = normalizeCandidateBlockGridConfig({
  sortField: "candidate.opt10",
});
```

DOM 기반 기능은 별도 entry로도 import할 수 있습니다.

```js
import {
  getDocumentSurfaceOverflowInfo,
  normalizeDocumentTokenNodes,
  sanitizeTemplateEditorHtml,
} from "examlist-template-editor/dom";
```

## Fixture

현재 데이터 계약을 확인하거나 consumer 테스트에 재사용할 수 있습니다.

```js
import template from "examlist-template-editor/fixtures/templates/current-layout-template.json" with { type: "json" };
import dataTags from "examlist-template-editor/fixtures/data-tags/examlist-data-tags.json" with { type: "json" };
```

template fixture에는 표지/본문, safe area, 페이지 번호, 인식 마크, 타 고사실, 후보 블록과 OPT10 정렬이 포함됩니다.

## 레이아웃

기본값은 ExamList와 같은 데스크톱 4열입니다. 좁은 컨테이너에서도 구조를 유지하고 필요한 경우 가로 스크롤을 사용합니다. 세로 적층이 필요할 때만 다음을 지정합니다.

```js
mountTemplateEditor({
  root,
  template,
  dataTags,
  layoutMode: "responsive",
});
```

## 검증과 원본 동기화

다음 명령은 패키지 소스 checkout에서 유지보수자와 CI가 실행하는 검증입니다. 설치된 소비 프로젝트의 `node_modules/examlist-template-editor`에서 실행하는 명령이 아니며, 배포 압축본에는 생성·테스트용 maintainer 스크립트가 포함되지 않습니다.

```bash
npm run verify
```

이 명령은 source fingerprint 확인, runtime/CSS 생성, Node 단위 테스트, TypeScript 공개 API 검사, Chromium 시나리오, pack 목록, 실제 임시 `.tgz` consumer 설치를 차례로 검증합니다. 원본 ExamList 소스 없이 독립 저장소에서 실행할 때도 기록된 fingerprint와 artifact hash가 맞지 않으면 실패합니다.

원본 파일별 이관 내역과 의도적인 adapter 경계는 [docs/migration.md](docs/migration.md), 전체 계약은 [docs/api.md](docs/api.md), 소비 프로젝트 연결 절차는 [docs/integration.md](docs/integration.md)를 참고하세요.
