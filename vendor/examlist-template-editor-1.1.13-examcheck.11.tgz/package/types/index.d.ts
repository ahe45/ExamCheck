export type DataTagFormatType = "date" | "time";

export interface DataTagDefinition {
  key?: string;
  dataKey?: string;
  token?: string;
  label?: string;
  type?: string;
  example?: unknown;
  [key: string]: unknown;
}

export interface DataTagGroup {
  id?: string;
  label?: string;
  tags?: DataTagDefinition[];
  [key: string]: unknown;
}

export interface DataTagCatalog {
  groups?: DataTagGroup[];
  tags?: DataTagDefinition[];
  [key: string]: unknown;
}

export interface TemplateEditorPageSettings {
  documentHtml?: string;
  editorMode?: string;
  safeArea?: Partial<PageSafeArea>;
  pageNumber?: Partial<PageNumberSettings>;
  recognitionMarks?: Partial<RecognitionMarkSettings>;
  otherRoomPage?: Partial<OtherRoomPageSettings>;
  candidateBlockGrid?: Partial<CandidateBlockGridConfig> & Record<string, unknown>;
  [key: string]: unknown;
}

export interface TemplateEditorPage {
  enabled?: boolean;
  heightPt?: number;
  id?: string;
  name?: string;
  repeatable?: boolean;
  settings?: TemplateEditorPageSettings;
  type?: string;
  widthPt?: number;
  [key: string]: unknown;
}

export interface TemplateEditorLayoutPayload {
  paper?: TemplateEditorPaperSettings;
  pages?: TemplateEditorPage[];
  [key: string]: unknown;
}

export interface TemplateEditorPaperSettings {
  heightPt?: number;
  margin?: Partial<PageSafeArea>;
  orientation?: string;
  preset?: string;
  widthPt?: number;
  [key: string]: unknown;
}

export interface TemplateLayoutPayload {
  layout?: TemplateEditorLayoutPayload;
  documentHtml?: string;
  html?: string;
  orientation?: string;
  paperPreset?: string;
  settings?: TemplateEditorPageSettings;
  [key: string]: unknown;
}

export type TemplateEditorValue = TemplateLayoutPayload | string;

export interface PreviewPdfRequest {
  editor: MountedTemplateEditor | null;
  html: string;
  sampleData: Record<string, unknown>;
  template: TemplateEditorValue;
}

export interface PreviewPdfResult {
  html?: string;
  pdfUrl?: string;
  pageCount?: number;
  candidateCount?: number;
  warnings?: string[];
  [key: string]: unknown;
}

export interface SaveTemplateRequest {
  editor: MountedTemplateEditor | null;
  html: string;
  template: TemplateEditorValue;
  [key: string]: unknown;
}

export interface UploadImageRequest {
  editor: MountedTemplateEditor | null;
  file: File;
  html: string;
  template: TemplateEditorValue;
  [key: string]: unknown;
}

export interface UploadedImageResult {
  url?: string;
  src?: string;
  href?: string;
  source?: string;
  path?: string;
  filePath?: string;
  key?: string;
  alt?: string;
  caption?: string;
  title?: string;
  name?: string;
  width?: number;
  height?: number;
  [key: string]: unknown;
}

export interface TemplateEditorAdapterMap {
  buildApiUrl?: (path: string) => string;
  resolveAssetUrl?: (path: string) => string;
  saveTemplate?: (context: SaveTemplateRequest) => Promise<TemplateEditorValue | void> | TemplateEditorValue | void;
  previewPdf?: (context: PreviewPdfRequest) => Promise<PreviewPdfResult> | PreviewPdfResult;
  uploadImage?: (context: UploadImageRequest) => Promise<UploadedImageResult | string | void> | UploadedImageResult | string | void;
}

export interface TemplateEditorPermissions {
  canManageTemplates?: boolean;
  [key: string]: unknown;
}

export type TemplateEditorElementTarget = Element | string | null;

export interface TemplateEditorRuntimeState {
  templateEditor?: Record<string, unknown>;
  templatePreview?: Record<string, unknown>;
  [key: string]: unknown;
}

export interface TemplateEditorTagDisplayContext {
  definition: Readonly<DataTagDefinition> | null;
  iconMarkup: string;
  label: string;
  tag: string;
}

export interface TemplateEditorTagDisplay {
  hideIcons?: boolean;
  iconMarkup?: string;
  sampleDisplay?: boolean;
  text?: string;
  title?: string;
}

export interface TemplateEditorPhotoUrlContext {
  buildApiUrl: (path: string) => string;
  previewPhotoPath: string;
  [key: string]: unknown;
}

export interface TemplateEditorRuntimeBaseOptions {
  root?: TemplateEditorElementTarget;
  document?: Document;
  toolbarHost?: TemplateEditorElementTarget;
  surface?: TemplateEditorElementTarget;
  tagHost?: TemplateEditorElementTarget;
  pagePropertiesHost?: TemplateEditorElementTarget;
  statusElement?: TemplateEditorElementTarget;
  tags?: DataTagDefinition[];
  idPrefix?: string;
  buildApiUrl?: (path: string) => string;
  previewData?: Record<string, unknown>;
  previewPhotoPath?: string;
  getPreviewData?: () => Record<string, unknown>;
  getPreviewDate?: () => string;
  historyLimit?: number;
  imageMinSize?: number;
  state?: TemplateEditorRuntimeState;
  getTemplateEditorTagDisplay?: (
    context: TemplateEditorTagDisplayContext,
  ) => TemplateEditorTagDisplay | null | void;
  buildPhotoUrl?: (record: Record<string, unknown>, context: TemplateEditorPhotoUrlContext) => string;
  getSchoolLogoDataUrl?: () => string | null | undefined;
  schoolLogoDataUrl?: string;
  getGeneratedObjectValue?: (record: Record<string, unknown>) => string;
  generatedObjectSourceKey?: string;
  [key: string]: unknown;
}

export interface CreateTemplateEditorOptions extends TemplateEditorRuntimeBaseOptions {
  initialHtml?: string;
  onChange?: (html: string, runtime: TemplateEditorRuntimeApi) => void;
  onSetHtml?: (
    html: string,
    runtime: TemplateEditorRuntimeApi,
    context: { notify: boolean; resetHistory: boolean },
  ) => void;
}

export type TemplateEditorRuntimeOptions = CreateTemplateEditorOptions;
export type RawTemplateEditorOptions = CreateTemplateEditorOptions;

export interface TemplateEditorRuntimeApi {
  applyCommand: (...args: unknown[]) => unknown;
  clearTableObjectHoverState: (options?: { updateOverlay?: boolean }) => unknown;
  clearTableObjectSelection: (options?: { updateOverlay?: boolean }) => unknown;
  destroy: () => void;
  getHtml: () => string;
  handleImageResizeStart: (event: Event) => unknown;
  insertHtml: (html: string, options?: { preserveTablePresentation?: boolean }) => unknown;
  insertImage: (file: File) => unknown;
  insertImageSource: (...args: unknown[]) => unknown;
  insertTag: (tag: string) => unknown;
  redo: () => unknown;
  render: (data?: Record<string, unknown>, html?: string) => string;
  renderInto: (target: Element | string, data?: Record<string, unknown>, html?: string) => string;
  renderPagePropertiesPanel: () => void;
  renderTagPanel: () => void;
  renderToolbar: () => void;
  setHtml: (html: string, options?: { notify?: boolean; resetHistory?: boolean }) => unknown;
  state: TemplateEditorRuntimeState;
  sync: (...args: unknown[]) => unknown;
  undo: () => unknown;
  updateImageSelectionOverlay: (...args: unknown[]) => unknown;
  updateTableObjectOverlay: (...args: unknown[]) => unknown;
}

export type RawTemplateEditor = TemplateEditorRuntimeApi;
export type RawTemplateEditorApi = TemplateEditorRuntimeApi;

export interface TemplateEditorRuntimeModule {
  createTemplateEditor: (options?: CreateTemplateEditorOptions) => TemplateEditorRuntimeApi;
  createTemplateEditorState: (overrides?: Record<string, unknown>) => Record<string, unknown>;
  createTemplatePreviewState: (overrides?: Record<string, unknown>) => Record<string, unknown>;
  normalizeTemplateTagDefinition: (definition?: DataTagDefinition) => Readonly<DataTagDefinition> | null;
  normalizeTemplateTagDefinitions: (definitions?: DataTagDefinition[]) => readonly Readonly<DataTagDefinition>[];
}

export interface MountTemplateEditorOptions extends TemplateEditorRuntimeBaseOptions {
  root?: Element | string | null;
  container?: Element | string | null;
  html?: string;
  initialHtml?: string;
  template?: TemplateEditorValue;
  selectedPageId?: string;
  dataTags?: DataTagDefinition[] | DataTagCatalog;
  adapters?: TemplateEditorAdapterMap;
  permissions?: TemplateEditorPermissions;
  readOnly?: boolean;
  layoutMode?: "desktop" | "responsive";
  responsiveLayout?: boolean;
  idPrefix?: string;
  clearRootOnDestroy?: boolean;
  blockSaveOnOverflow?: boolean;
  sanitizeHtml?: boolean;
  resolveAssetUrl?: (path: string) => string;
  onChange?: (
    nextTemplate: TemplateEditorValue,
    context: {
      editor: MountedTemplateEditor | null;
      html: string;
      runtime: TemplateEditorRuntimeApi;
      selectedPageId: string;
    },
  ) => void;
  onDirtyChange?: (isDirty: boolean) => void;
  onOverflowChange?: (info: TemplateEditorOverflowInfo, message: string) => void;
  onSetHtml?: (
    html: string,
    runtime: TemplateEditorRuntimeApi,
    context: { notify: boolean; resetHistory: boolean },
  ) => void;
  onUploadError?: (error: unknown, context: { editor: MountedTemplateEditor | null; file: File }) => void;
}

export interface MountedTemplateEditor {
  applyCommand: (...args: unknown[]) => unknown;
  clearTableObjectHoverState: TemplateEditorRuntimeApi["clearTableObjectHoverState"];
  clearTableObjectSelection: TemplateEditorRuntimeApi["clearTableObjectSelection"];
  destroy: () => void;
  focus: () => void;
  getHtml: () => string;
  getOverflowInfo: () => TemplateEditorOverflowInfo;
  getRuntime: () => TemplateEditorRuntimeApi;
  getSelectedPageId: () => string;
  getValue: () => TemplateEditorValue;
  handleImageResizeStart: TemplateEditorRuntimeApi["handleImageResizeStart"];
  insertHtml: (html: string) => unknown;
  insertImage: (file: File, context?: Record<string, unknown>) => Promise<boolean>;
  insertImageFile: (file: File, context?: Record<string, unknown>) => Promise<boolean>;
  insertImageSource: (...args: unknown[]) => unknown;
  insertUploadedImage: (uploadResult: UploadedImageResult | string, context?: { file?: File; [key: string]: unknown }) => boolean;
  insertTag: (tag: string) => unknown;
  isDirty: () => boolean;
  preview: (context?: Record<string, unknown>) => Promise<PreviewPdfResult>;
  redo: () => unknown;
  render: (data?: Record<string, unknown>, html?: string) => string;
  renderInto: (target: Element | string, data?: Record<string, unknown>, html?: string) => string;
  renderPagePropertiesPanel: TemplateEditorRuntimeApi["renderPagePropertiesPanel"];
  renderTagPanel: TemplateEditorRuntimeApi["renderTagPanel"];
  renderToolbar: TemplateEditorRuntimeApi["renderToolbar"];
  save: (context?: Record<string, unknown>) => Promise<TemplateEditorValue | void>;
  setHtml: (html: string, options?: { notify?: boolean; resetHistory?: boolean }) => unknown;
  setReadOnly: (isReadOnly: boolean) => void;
  setSelectedPage: (
    selectedPageId: string,
    options?: { markClean?: boolean; notify?: boolean; resetHistory?: boolean },
  ) => string;
  setValue: (
    nextValue: TemplateEditorValue,
    options?: {
      html?: string;
      markClean?: boolean;
      notify?: boolean;
      resetHistory?: boolean;
      selectedPageId?: string;
    },
  ) => void;
  state: TemplateEditorRuntimeState;
  sync: () => TemplateEditorValue;
  undo: () => unknown;
  updateImageSelectionOverlay: TemplateEditorRuntimeApi["updateImageSelectionOverlay"];
  updateTableObjectOverlay: TemplateEditorRuntimeApi["updateTableObjectOverlay"];
  uploadImage: (file: File, context?: Record<string, unknown>) => Promise<boolean>;
}

export interface DataTagSampleValueConstraint {
  errorMessage: string;
  formatLabel: string;
  inputMode: string;
  maxLength: number;
  placeholder: string;
  type: DataTagFormatType;
}

export interface DataTagFormatOption {
  label: string;
  preview: string;
  value: string;
}

export interface DataTagFormatTokenGuide {
  description: string;
  example: string;
  token: string;
}

export const dateFormatType: "date";
export const timeFormatType: "time";
export const dataTagSampleValuesEventName: "examlist:data-tag-sample-values-change";
export const dataTagSettingsEventName: "examlist:data-tag-settings-change";

export function getTemplateEditorRuntime(): TemplateEditorRuntimeModule;
export function createTemplateEditor(options?: CreateTemplateEditorOptions): TemplateEditorRuntimeApi;
export function createTemplateEditorState(overrides?: Record<string, unknown>): Record<string, unknown>;
export function createTemplatePreviewState(overrides?: Record<string, unknown>): Record<string, unknown>;
export function normalizeTemplateTagDefinition(definition?: DataTagDefinition): Readonly<DataTagDefinition> | null;
export function normalizeTemplateTagDefinitions(definitions?: DataTagDefinition[]): readonly Readonly<DataTagDefinition>[];
export function mountTemplateEditor(options?: MountTemplateEditorOptions): MountedTemplateEditor;

export function getDataTagDefinitionKey(definitionOrKey?: DataTagDefinition | string): string;
export function getDataTagFormatType(definitionOrKey?: DataTagDefinition | string): DataTagFormatType | "";
export function isDataTagFormatSupported(definitionOrKey?: DataTagDefinition | string): boolean;

export function getDataTagSampleValueConstraint(definitionOrKey?: DataTagDefinition | string): Readonly<DataTagSampleValueConstraint> | null;
export function getDataTagSampleValueError(definitionOrKey?: DataTagDefinition | string, value?: unknown): string;
export function normalizeDataTagSampleValue(definitionOrKey?: DataTagDefinition | string, value?: unknown): string;
export function buildDataTagSampleValueErrors(tagDefinitions?: DataTagDefinition[], sampleValues?: Record<string, unknown>): Record<string, string>;
export function hasDataTagSampleValueErrors(errors?: Record<string, unknown>): boolean;
export function formatDataTagValue(formatType?: string, value?: unknown, formatValue?: string): string;
export function formatDataTagSampleValue(
  definitionOrKey?: DataTagDefinition | string,
  value?: unknown,
  formatValue?: string,
  explicitFormatType?: string,
): string;

export function normalizeDataTagDefinition(definition?: DataTagDefinition): DataTagDefinition | null;
export function flattenDataTagDefinitions(dataTags?: DataTagCatalog | DataTagDefinition[]): DataTagDefinition[];
export function findDataTagDefinitionByKey(dataTags?: DataTagCatalog | DataTagDefinition[], tagKey?: string): DataTagDefinition | null;
export const findDataTagFormatDefinitionByKey: typeof findDataTagDefinitionByKey;

export function getDataTagFormatOptions(formatType?: string): readonly Readonly<DataTagFormatOption>[];
export function getDataTagFormatTokenGuides(formatType?: string): readonly Readonly<DataTagFormatTokenGuide>[];
export function isDataTagFormatValid(formatType?: string, formatValue?: string): boolean;
export function normalizeDataTagFormat(formatType?: string, formatValue?: string): string;
export function getDataTagFormatInputError(formatType?: string, formatValue?: string): string;
export function renderDataTagFormatPreview(formatType?: string, formatValue?: string): string;

export function buildDefaultDataTagSampleValues(tagDefinitions?: DataTagDefinition[]): Record<string, string>;
export function buildDefaultDataTagEmptyValueData(tagDefinitions?: DataTagDefinition[]): Record<string, string>;
export function normalizeDataTagSampleValues(tagDefinitions?: DataTagDefinition[], sampleValues?: Record<string, unknown>): Record<string, string>;
export function normalizeDataTagEmptyValueData(tagDefinitions?: DataTagDefinition[], emptyValueData?: Record<string, unknown>): Record<string, string>;
export function loadDataTagSampleValues(tagDefinitions?: DataTagDefinition[], sourceValues?: Record<string, unknown> | null): Record<string, string>;
export function loadDataTagEmptyValueData(tagDefinitions?: DataTagDefinition[], sourceValues?: Record<string, unknown> | null): Record<string, string>;
export function saveDataTagSampleValues(tagDefinitions?: DataTagDefinition[], sampleValues?: Record<string, unknown>): Record<string, string>;
export function saveDataTagEmptyValueData(tagDefinitions?: DataTagDefinition[], emptyValueData?: Record<string, unknown>): Record<string, string>;
export function applyDataTagSampleValuesToDefinitions(tagDefinitions?: DataTagDefinition[], sampleValues?: Record<string, unknown>): DataTagDefinition[];
export function createDataTagSampleValuesPayload(tagDefinitions?: DataTagDefinition[], sampleValues?: Record<string, unknown>): Record<string, string>;
export function createDataTagEmptyValueDataPayload(tagDefinitions?: DataTagDefinition[], emptyValueData?: Record<string, unknown>): Record<string, string>;
export function createDataTagSettingsPayload(
  tagDefinitions?: DataTagDefinition[],
  values?: {
    emptyValueData?: Record<string, unknown>;
    sampleData?: Record<string, unknown>;
  },
): {
  emptyValueData: Record<string, string>;
  sampleData: Record<string, string>;
};
export function areDataTagSampleValuesEqual(
  tagDefinitions?: DataTagDefinition[],
  leftValues?: Record<string, unknown>,
  rightValues?: Record<string, unknown>,
): boolean;
export function areDataTagEmptyValueDataEqual(
  tagDefinitions?: DataTagDefinition[],
  leftValues?: Record<string, unknown>,
  rightValues?: Record<string, unknown>,
): boolean;

// Portable core settings and generated-object utilities.

export interface DataTagViewOptions {
  showIcons: boolean;
  showSampleData: boolean;
}

export const dataTagViewOptionsEventName: "examlist:data-tag-view-options-change";
export const defaultDataTagViewOptions: Readonly<DataTagViewOptions>;
export function normalizeDataTagViewOptions(options?: Partial<DataTagViewOptions> | null): Readonly<DataTagViewOptions>;

export interface PageSafeArea {
  bottom: number;
  left: number;
  right: number;
  top: number;
}

export interface TemplatePaperSettingsTarget {
  layout?: {
    pages?: Array<Record<string, unknown> & { heightPt?: number; widthPt?: number }>;
    paper?: Record<string, unknown> & {
      heightPt?: number;
      orientation?: string;
      preset?: string;
      widthPt?: number;
    };
    [key: string]: unknown;
  };
  orientation?: string;
  paperPreset?: string;
  [key: string]: unknown;
}

export const defaultPageSafeArea: Readonly<PageSafeArea>;
export const pageMarginFields: Set<keyof PageSafeArea>;
export function normalizeBooleanValue(value?: unknown, fallback?: boolean): boolean;
export function getFormFieldValue(
  target?: { checked?: boolean; type?: string; value?: unknown } | null,
): unknown;
export function normalizePageMarginValue(value?: unknown, fallback?: number): number;
export function normalizePageSafeArea(
  value?: Partial<PageSafeArea> | null,
  fallbackMargin?: Partial<PageSafeArea> | null,
): PageSafeArea;
export function applyTemplatePaperSettings(template: TemplatePaperSettingsTarget): void;

export type RuntimePageOrientation = "portrait" | "landscape";
export type RuntimePageSize = "A3" | "A4" | "B5" | "LETTER" | "LEGAL";
export type ExamListPaperPreset = "A3" | "A4" | "B5" | "Letter" | "Legal";

export interface RuntimePageSettings {
  marginBottom: number;
  marginLeft: number;
  marginRight: number;
  marginTop: number;
  orientation: RuntimePageOrientation;
  size: string;
}

export interface PaperPresetDimensions {
  heightPt: number;
  widthPt: number;
}

export const supportedRuntimePageSizes: Set<RuntimePageSize>;
export const examListPaperPresetByRuntimeSize: Readonly<Record<RuntimePageSize, ExamListPaperPreset>>;
export const runtimePageSizeByExamListPaperPreset: Readonly<Record<ExamListPaperPreset, RuntimePageSize>>;
export const paperPresetDimensionsPt: Readonly<Record<ExamListPaperPreset, Readonly<PaperPresetDimensions>>>;

export function toFiniteNumber(value?: unknown, fallback?: number): number;
export function toMillimeterValue(pointValue?: unknown): number;
export function toPointValue(millimeterValue?: unknown): number;
export function normalizeOrientation(value?: unknown): RuntimePageOrientation;
export function getRuntimePageSizeFromTemplate(template?: TemplateLayoutPayload | null): RuntimePageSize;
export function getSafeAreaPt(
  page?: TemplateEditorPage | null,
  template?: TemplateLayoutPayload | null,
): PageSafeArea;
export function getRuntimePageSettings(
  page?: TemplateEditorPage | null,
  template?: TemplateLayoutPayload | null,
): RuntimePageSettings;
export function readRuntimePageSettingsFromHtml(html?: string): RuntimePageSettings;
export function writeRuntimePageSettingsToHtml(
  html?: string,
  settings?: Partial<RuntimePageSettings>,
): string;
export function applyPaperSettingsToTemplate(
  template: TemplateLayoutPayload,
  settings: RuntimePageSettings,
  initialPaperPreset?: string,
): boolean;
export function applySafeAreaToTemplate(
  template: TemplateLayoutPayload,
  selectedPage: TemplateEditorPage,
  settings: RuntimePageSettings,
): boolean;
export function prepareTemplatePageHtml(
  template?: TemplateLayoutPayload | null,
  pageId?: string,
  html?: string,
): string;
export function syncTemplatePageSettingsFromHtml(
  template: TemplateLayoutPayload,
  pageId?: string,
  html?: string,
  initialPaperPreset?: string,
): TemplateLayoutPayload;

export type PageNumberPreset =
  | "numericCurrentTotal"
  | "pageCurrentTotal"
  | "pageCurrentTotalEnglish"
  | "currentPageKorean"
  | "koreanPage"
  | "currentPageOfTotalKorean"
  | "koreanPageOfTotal";
export type PageNumberPosition = "left" | "center" | "right";

export interface PageNumberSettings {
  enabled: boolean;
  position: PageNumberPosition;
  preset: PageNumberPreset;
}

export interface RecognitionMarkSettings {
  enabled: boolean;
  offsetXPt: number;
  offsetYPt: number;
  sizePt: number;
}

export interface OtherRoomPageSettings {
  enabled: boolean;
}

export interface CandidateBlockGridSortNormalizers {
  normalizeSortDirection?: (value: unknown) => CandidateBlockGridSortDirection;
  normalizeCandidateBlockGridSortDirection?: (value: unknown) => CandidateBlockGridSortDirection;
  normalizeSortKey?: (value: unknown) => string;
  normalizeCandidateBlockGridSortKey?: (value: unknown) => string;
}

export const supportedPageNumberPresets: readonly PageNumberPreset[];
export const supportedPageNumberPositions: readonly PageNumberPosition[];
export function normalizeRecognitionMarks(settings?: unknown): RecognitionMarkSettings;
export function normalizePageNumberSettings(settings?: unknown): PageNumberSettings;
export function normalizeOtherRoomPageSettings(settings?: unknown): OtherRoomPageSettings;
export function isCoverPageType(value?: unknown): boolean;
export function isSmokeCandidateBlockTemplateHtml(value?: unknown): boolean;
export function normalizeCandidateBlockGridSettings(
  settings?: unknown,
  normalizers?: CandidateBlockGridSortNormalizers,
): CandidateBlockGridConfig;
export function normalizePageSettings(
  settings?: TemplateEditorPageSettings | null,
  paperConfig?: { margin?: Partial<PageSafeArea>; [key: string]: unknown } | null,
  pageType?: string,
  candidateBlockGridNormalizers?: CandidateBlockGridSortNormalizers,
): TemplateEditorPageSettings;

export interface TemplateEditorOverflowInfo {
  hasOverflow: boolean;
  heightOverflow: number;
  widthOverflow: number;
}

export interface TemplateEditorOverflowError extends Error {
  code: "TEMPLATE_EDITOR_OVERFLOW";
  overflow: TemplateEditorOverflowInfo;
}

export function sanitizeNodeTree(rootNode?: ParentNode | null): void;
export function normalizeDocumentFontNodes(rootNode?: ParentNode | null): void;
export function stripTransientDocumentState(rootElement?: ParentNode | null): void;
export function sanitizeTemplateEditorHtml(value?: unknown, documentRef?: Document): string;
export function getDocumentContentRoot(surface?: Element | null): Element | null;
export function getDocumentSurfaceOverflowInfo(surface?: Element | null): TemplateEditorOverflowInfo;
export function getDocumentOverflowMessage(overflowInfo?: Partial<TemplateEditorOverflowInfo> | null): string;

export type CandidateBlockGridSortDirection = "asc" | "desc";

export interface CandidateBlockTemplateSettings {
  enabled: boolean;
  templateHtml: string;
}

export interface CandidateBlockColumnNameRowSettings extends CandidateBlockTemplateSettings {
  heightPt: number;
}

export interface CandidateBlockGridConfig {
  blockTemplateHtml: string;
  columnNameRow: CandidateBlockColumnNameRowSettings;
  columns: number;
  enabled: boolean;
  emptyBlockLayer: CandidateBlockTemplateSettings;
  fillEmptyBlocks: boolean;
  gapXPt: number;
  gapYPt: number;
  heightPt: number;
  rows: number;
  sortDirection: CandidateBlockGridSortDirection;
  sortKey: string;
  variant: "photo";
  widthPt: number;
  xPt: number;
  yPt: number;
}

export interface CandidateBlockGridPage {
  type?: unknown;
  settings?: {
    candidateBlockGrid?: unknown;
    [key: string]: unknown;
  };
  [key: string]: unknown;
}

export interface CandidateBlockGridSortOption {
  key: string;
  label: string;
}

export const templateEditorTableObjectBorderHitSlop: 8;
export const candidateBlockFocusTableObjectOuterHitSlop: 24;
export const candidateBlockGridMinimumRowHeight: 20;
export const candidateBlockGridMinimumHeight: 20;
export const candidateBlockGridMinimumWidth: 120;
export const candidateBlockGridColumnNameRowDefaultHeightPt: 20;
export const candidateBlockGridColumnNameRowMinimumHeightPt: 4;
export const candidateBlockGridColumnNameRowMaximumHeightPt: 240;
export const candidateBlockGridDefaults: Readonly<{
  blockTemplateHtml: string;
  columnNameRow: Readonly<CandidateBlockColumnNameRowSettings>;
  columns: number;
  enabled: boolean;
  emptyBlockLayer: Readonly<CandidateBlockTemplateSettings>;
  fillEmptyBlocks: boolean;
  gapXPt: number;
  gapYPt: number;
  rows: number;
  sortDirection: CandidateBlockGridSortDirection;
  sortKey: string;
  variant: "photo";
  xPt: number;
  yPt: number;
}>;
export const objectResizeCorners: readonly string[];
export const candidateBlockGridSortOptions: readonly Readonly<CandidateBlockGridSortOption>[];

export function clampInteger(value: unknown, fallback: number, minimum: number, maximum: number): number;
export function clampPointValue(value: unknown, fallback: number, minimum: number, maximum: number): number;
export function pointValueToCssPixel(value: unknown): number;
export function cssPixelToPointValue(value: unknown): number;
export function normalizeCandidateBlockColumnNameRowHeightPt(value: unknown, fallback?: number): number;
export function normalizeCandidateBlockColumnNameRowHeightPx(value: unknown, fallback?: number): number;
export function cssPixelToCandidateBlockColumnNameRowHeightPt(value: unknown, fallback?: number): number;
export function normalizeCandidateBlockGridSortKey(value?: unknown): string;
export function normalizeCandidateBlockGridSortDirection(value?: unknown): CandidateBlockGridSortDirection;
export function normalizeCandidateBlockTemplateHtml(value?: unknown): string;
export function normalizeCandidateBlockGridConfig(value?: unknown): CandidateBlockGridConfig;
export function getCandidateBlockGridConfig(page?: CandidateBlockGridPage | null): CandidateBlockGridConfig;
export function isCandidateBlockGridContentPage(page?: CandidateBlockGridPage | null): boolean;
export function canUseCandidateBlockGrid(page?: CandidateBlockGridPage | null): boolean;
export function isPhotoCandidateBlockGridPage(page?: CandidateBlockGridPage | null): boolean;
export function getCandidateBlockGridTotal(config?: unknown): number;

export function getCandidateBlockTemplateSourceElement(rootElement?: ParentNode | null): Element | null;
export function isCandidateBlockTemplateSource(blockElement?: unknown): boolean;
export function isCandidateBlockTemplatePreview(blockElement?: unknown): boolean;
export function applyCandidateBlockTemplateRoles(gridElement?: ParentNode | null): HTMLElement | null;

export interface Code128Sequence {
  checksum: number;
  sequence: number[];
  value: string;
}

export interface Code128SvgOptions {
  backgroundColor?: string;
  barColor?: string;
  height?: number;
  width?: number;
}

export function normalizeCode128BValue(value?: unknown): string;
export function buildCode128BSequence(value?: unknown): Code128Sequence;
export function buildCode128Svg(value?: unknown, options?: Code128SvgOptions): string;

export type GeneratedObjectType = "barcode" | "qrcode";

export interface GeneratedObjectConfig {
  altSuffix: string;
  className: string;
  height: number;
  label: string;
  labelSuffix: string;
  width: number;
}

export interface GeneratedObjectSourceOption {
  example: string;
  key: string;
  label: string;
}

export interface GeneratedObjectPreviewOptions {
  currentDate?: string;
  hasPhoto?: boolean;
  photoFileId?: string;
  photoUrl?: string;
  useTemplatePreviewPhoto?: boolean;
}

export interface GeneratedObjectPreviewData extends Record<string, unknown> {
  candidate: Record<string, string>;
  currentDate: string;
  hasPhoto: boolean;
  photoFileId: string;
  photoUrl: string;
  school: Record<string, string>;
  useTemplatePreviewPhoto: boolean;
}

export const generatedObjectDefaults: Readonly<Record<GeneratedObjectType, Readonly<GeneratedObjectConfig>>>;
export const generatedObjectPreviewValues: Readonly<Record<string, string>>;
export const code128GeneratedObjectSourceKeys: Set<string>;
export const generatedObjectSourceAliases: Readonly<Record<string, readonly string[]>>;
export const generatedObjectPreviewPhotoDefaults: Readonly<{ fileId: string; url: string }>;

export function normalizeGeneratedObjectType(value?: unknown): GeneratedObjectType;
export function resolveGeneratedObjectType(value?: unknown): GeneratedObjectType | "";
export function normalizeGeneratedObjectSourceKey(value?: unknown): string;
export function isCode128GeneratedObjectSourceKey(value?: unknown): boolean;
export function filterGeneratedObjectSourceOptionsForType<
  T extends { key?: unknown; dataKey?: unknown; token?: unknown },
>(
  options?: T[],
  objectType?: string,
): T[];
export function getGeneratedObjectConfig(objectType?: unknown): Readonly<GeneratedObjectConfig> | null;
export function uniqueGeneratedObjectValues(values?: unknown[]): string[];
export function getGeneratedObjectSourceOptions(tagDefinitions?: DataTagDefinition[]): GeneratedObjectSourceOption[];
export function getGeneratedObjectSourceLabel(sourceKey?: unknown, tagDefinitions?: DataTagDefinition[]): string;
export function readValueAtPath(source: unknown, path?: unknown): unknown;
export function resolveGeneratedObjectPreviewValue(
  record: unknown,
  sourceKey?: unknown,
  tagDefinitions?: DataTagDefinition[],
): string;
export function buildGeneratedObjectPreviewData(
  tagDefinitions?: DataTagDefinition[],
  options?: GeneratedObjectPreviewOptions,
): GeneratedObjectPreviewData;
export function createGeneratedObjectSvgDataUrl(svgMarkup?: unknown): string;
export function buildGeneratedObjectSvg(objectType?: unknown, objectValue?: unknown): string;

export interface DataTagAccordionGroup {
  icon: string;
  id: string;
  keys: readonly string[];
  label: string;
}

export const hiddenTemplateTagKeys: Set<string>;
export const dataTagAccordionGroups: readonly Readonly<DataTagAccordionGroup>[];
export const dataTagFallbackDefinitions: Readonly<Record<string, Readonly<DataTagDefinition>>>;
export function renderDataTagIcon(iconKey?: string): string;
export function getDataTagGroupForKey(key?: string): Readonly<DataTagAccordionGroup> | null;
export function isVisibleTemplateTag(tag?: DataTagDefinition): boolean;

export interface GenerationUnitFieldOption {
  key: string;
  label: string;
}

export const generationUnitPriorityDefaults: readonly string[];
export const generationUnitPriorityMaximum: 5;
export const generationUnitPriorityMinimumRows: 4;
export function getGenerationUnitFieldOptions(): readonly Readonly<GenerationUnitFieldOption>[];
export function normalizeGenerationUnitFields(fields?: unknown[], fallback?: readonly string[] | null): string[];
export function getTemplateGenerationUnitFields(template?: TemplateLayoutPayload): string[];
export function getGenerationUnitFieldLabel(field?: string): string;
export function formatGenerationUnitFieldsSummary(fields?: unknown[]): string;
export function getVisibleGenerationUnitPriorityRowCount(fields?: unknown[]): number;
export function writeGenerationUnitSettingsToTemplate(template: TemplateLayoutPayload, fields?: unknown[]): string[];

export interface GeneratedObjectMarkupOptions {
  previewRecord?: Record<string, unknown> | null;
  tagDefinitions?: DataTagDefinition[];
}

export function buildGeneratedObjectMarkup(
  objectType?: unknown,
  objectSourceKey?: string,
  options?: GeneratedObjectMarkupOptions,
): string;

export interface RectLike {
  bottom?: number;
  height?: number;
  left?: number;
  right?: number;
  top?: number;
  width?: number;
}

export interface SizeLike {
  height?: number;
  width?: number;
}

export interface CandidateBlockFocusHostMetrics {
  left: number;
  scaleX: number;
  scaleY: number;
  top: number;
}

export interface CandidateBlockFocusLayoutOptions {
  layerBorderWidth?: number;
  maxScale?: number;
  minScale?: number;
  minVisualHeight?: number;
  minVisualWidth?: number;
  panelPaddingX?: number;
  panelPaddingY?: number;
}

export interface CandidateBlockFocusLayout {
  editorHeight: number;
  editorWidth: number;
  panelHeight: number;
  panelLeft: number;
  panelTop: number;
  panelWidth: number;
  scale: number;
  visualHeight: number;
  visualWidth: number;
}

export function parseCandidateBlockPixelValue(value?: unknown, fallback?: number): number;
export function toFinitePixelValue(value: unknown, fallback: number): number;
export function parseCssPixelValue(value?: unknown): number;
export function calculateCandidateBlockFocusHostMetrics(
  hostRect?: RectLike | null,
  hostSize?: SizeLike,
): CandidateBlockFocusHostMetrics;
export function translateCandidateBlockFocusViewportRectToHostRect(
  viewportRect?: RectLike | null,
  hostMetrics?: Partial<CandidateBlockFocusHostMetrics>,
): Required<Pick<RectLike, "height" | "left" | "top" | "width">>;
export function calculateVisibleCanvasRect(
  canvasRect?: RectLike | null,
  viewportSize?: SizeLike,
): Required<RectLike>;
export function calculateCanvasBackdropRect(
  canvasRect?: RectLike | null,
  viewportSize?: SizeLike,
): Required<Pick<RectLike, "height" | "left" | "top" | "width">>;
export function calculateCandidateBlockFocusLayout(
  canvasRect: Required<Pick<RectLike, "height" | "left" | "top" | "width">>,
  logicalSize: Required<SizeLike>,
  options?: CandidateBlockFocusLayoutOptions,
): CandidateBlockFocusLayout;

export interface DocumentTokenOptions {
  document?: Document;
  iconMarkup?: string;
  preservePresentation?: boolean;
}

export function normalizeDocumentTokenTag(rawTag?: unknown): string;
export function getDocumentTokenDisplayText(rawTag?: unknown): string;
export function createDocumentTokenElement(
  rawTag?: unknown,
  displayLabel?: string,
  options?: DocumentTokenOptions,
): HTMLSpanElement;
export function buildDocumentTokenHtml(
  rawTag?: unknown,
  displayLabel?: string,
  options?: DocumentTokenOptions,
): string;
export function normalizeDocumentTokenNodes(rootElement?: ParentNode | null, options?: DocumentTokenOptions): void;

export type DocumentImageResizeCorner =
  | "bottom-right"
  | "bottom"
  | "bottom-left"
  | "left"
  | "top-left"
  | "top"
  | "top-right"
  | "right";

export const editorCanvasDisplayScale: number;
export const documentObjectMinimumSize: 5;
export const documentImageResizeCorners: readonly DocumentImageResizeCorner[];
export const documentImageResizeClassNames: readonly string[];
export function parseDocumentPixelValue(value?: unknown, fallback?: number): number;
export function getDocumentElementDisplayScale(
  element?: Element | null,
  fallbackScale?: number,
): { x: number; y: number };
export function normalizeObjectResizeCorner(value?: unknown): DocumentImageResizeCorner;
export function getObjectResizeDirections(corner?: unknown): { x: -1 | 0 | 1; y: -1 | 0 | 1 };
export function getDocumentBoundedCoordinate(value: unknown, maxValue: unknown): number;

export const objectFlowLayoutChangeEventName: "examlist:object-flow-layoutchange";
export function syncTemplateEditorObjectFlowObjects(
  documentElement?: HTMLElement | null,
  options?: Record<string, unknown>,
): HTMLElement[];
export function reflowTemplateEditorObjectRows(
  activeElement?: HTMLElement | null,
  options?: { documentElement?: HTMLElement | null; [key: string]: unknown },
): { shiftedObjects: HTMLElement[]; spacerElement: HTMLElement | null };
export function normalizeObjectTableSegmentSizes(
  sizes: number[],
  targetSize: number,
  minimumSize?: number,
): number[];

export type CandidateBlockBoundaryDirection = "backward" | "forward";
export function isIgnorableCandidateBlockBoundaryNode(
  node?: Node | null,
  HtmlElementConstructor?: typeof HTMLElement | null,
): boolean;
export function getAdjacentCandidateBlockBoundaryNode(
  parentNode: ParentNode | null,
  startIndex: number,
  direction: CandidateBlockBoundaryDirection,
): Node | null;
export function getCandidateBlockGridFromBoundaryNode(
  node?: Node | null,
  direction?: CandidateBlockBoundaryDirection,
): HTMLElement | null;
export function getCandidateBlockGridAdjacentToRange(
  range: Range | null,
  direction: CandidateBlockBoundaryDirection,
  surfaceElement: HTMLElement,
): HTMLElement | null;
export function doesRangeIncludeCandidateBlockGrid(range: Range | null, surfaceElement: HTMLElement): boolean;
export function getCandidateBlockBoundaryHostElement(
  range: Range | null,
  surfaceElement: HTMLElement,
): HTMLElement | null;
export function getCandidateBlockGridSibling(
  element: HTMLElement | null,
  direction: CandidateBlockBoundaryDirection,
  surfaceElement: HTMLElement,
): HTMLElement | null;
export function isBlankBoundaryHostAdjacentToCandidateBlockGrid(
  range: Range | null,
  surfaceElement: HTMLElement,
): boolean;
export function shouldPreventCandidateBlockGridNativeDeletion(
  event: Pick<KeyboardEvent, "key"> | null,
  surfaceElement: HTMLElement,
): boolean;
export function normalizeCandidateBlockBoundaryHostHtml(value?: unknown): string;
export function isBlankCandidateBlockBoundaryHost(element?: HTMLElement | null): boolean;

export interface CandidateBlockKeyboardDeleteContext {
  activeElement?: Element | null;
  activeGridElement?: Element | null;
  activeSurfaceElement?: Element | null;
  gridElement?: Element | null;
  isActiveDocumentBody?: boolean;
  isActiveDocumentElement?: boolean;
  isActiveExternalEditingControl?: boolean;
  isTargetDocumentBody?: boolean;
  isTargetExternalEditingControl?: boolean;
  surfaceElement?: Element | null;
  targetElement?: Element | null;
  targetGridElement?: Element | null;
  targetSurfaceElement?: Element | null;
}

export function isCandidateBlockGridExternalEditingControl(
  element: Element | null,
  gridElement: Element | null,
  surfaceElement: Element | null,
  ElementConstructor?: typeof Element | null,
): boolean;
export function shouldHandleCandidateBlockGridKeyboardDelete(
  context?: CandidateBlockKeyboardDeleteContext,
): boolean;
export function isCandidateBlockGridKeyboardDeleteTarget(
  event: Event | null,
  surfaceElement: HTMLElement,
  gridElement: HTMLElement,
): boolean;

export interface CandidateBlockTableCellEntry {
  cell: HTMLTableCellElement;
  colIndex: number;
  colSpan: number;
  rowIndex: number;
  rowSpan: number;
}

export const candidateBlockTableMinimumCellSize: 1;
export function buildCandidateBlockTableCellEntries(
  tableElement?: HTMLTableElement | null,
): Map<HTMLTableCellElement, CandidateBlockTableCellEntry>;
export function getCandidateBlockTableColumnCount(tableElement?: HTMLTableElement | null): number;
export function getCandidateBlockTableMinimumSegmentSize(
  tableElement: HTMLTableElement,
  axis: "column" | "row",
): number;
export function getCandidateBlockElementChromeSize(
  blockElement?: HTMLElement | null,
): { horizontal: number; vertical: number };
export function getCandidateBlockCollapsedBorderAdjustment(
  tableElement: HTMLTableElement | null,
  axis: "column" | "row",
): number;
export function distributeCandidateBlockTableSizes(
  currentSizes: number[],
  targetSize: number,
  minimumSize?: number,
): number[];
export function normalizeCandidateBlockTables(rootElement?: ParentNode | null): void;
export function getCandidateBlockGridTableMinimumSize(
  gridElement?: HTMLElement | null,
): { height: number; width: number };
export function normalizeCandidateBlockTemplateHtmlFromElement(
  blockElement?: HTMLElement | null,
  fallbackHtml?: string,
): string;

export type TemplateEditorCanvasZoomMode = "fit" | "manual";

export interface TemplateEditorCanvasZoomState {
  canvasZoom?: number;
  canvasZoomMode?: TemplateEditorCanvasZoomMode | string;
  [key: string]: unknown;
}

export interface TemplateEditorCanvasZoomFocalPoint {
  clientX: number;
  clientY: number;
}

export interface TemplateEditorCanvasZoomOptions {
  editorState?: TemplateEditorCanvasZoomState | null;
  focalPoint?: TemplateEditorCanvasZoomFocalPoint | null;
  mode?: TemplateEditorCanvasZoomMode;
  onAfterApply?: (() => void) | null;
  onUpdateOverlays?: ((context: {
    canvasElement: Element;
    mode: TemplateEditorCanvasZoomMode;
    zoom: number;
  }) => void) | null;
  requestAnimationFrame?: ((callback: () => void) => unknown) | null;
  rootElement?: Element | Document | null;
  zoom?: number;
}

export const templateEditorCanvasZoomDefault: 1;
export const templateEditorCanvasZoomMin: 0.5;
export const templateEditorCanvasZoomMax: 3;
export const templateEditorCanvasZoomStep: 0.1;
export const templateEditorCanvasZoomModeFit: "fit";
export const templateEditorCanvasZoomModeManual: "manual";
export function normalizeTemplateEditorCanvasZoom(value?: unknown, fallback?: number): number;
export function normalizeTemplateEditorCanvasZoomMode(value?: unknown): TemplateEditorCanvasZoomMode;
export function getTemplateEditorCanvasZoom(editorState?: TemplateEditorCanvasZoomState): number;
export function getTemplateEditorCanvasZoomMode(
  editorState?: TemplateEditorCanvasZoomState,
): TemplateEditorCanvasZoomMode;
export function getTemplateEditorCanvasZoomPercentLabel(value?: unknown): string;
export function getTemplateEditorCanvasElement(rootElement?: Element | Document | null): Element | null;
export function calculateTemplateEditorCanvasFitZoom(canvasElement?: Element | null): number;
export function applyTemplateEditorCanvasZoom(options?: TemplateEditorCanvasZoomOptions): boolean;
export function applyTemplateEditorCanvasZoomFromState(
  options?: Omit<TemplateEditorCanvasZoomOptions, "focalPoint" | "mode" | "zoom"> & { recomputeFit?: boolean },
): boolean;
export function stepTemplateEditorCanvasZoom(
  editorState: TemplateEditorCanvasZoomState,
  direction?: number,
  options?: Omit<TemplateEditorCanvasZoomOptions, "editorState" | "mode" | "zoom">,
): boolean;
export function resetTemplateEditorCanvasZoom(
  editorState: TemplateEditorCanvasZoomState,
  options?: Omit<TemplateEditorCanvasZoomOptions, "editorState" | "mode" | "zoom">,
): boolean;
export function fitTemplateEditorCanvasZoom(
  editorState: TemplateEditorCanvasZoomState,
  options?: Omit<TemplateEditorCanvasZoomOptions, "editorState" | "mode" | "zoom">,
): boolean;
export function handleTemplateEditorCanvasZoomWheel(
  event: Pick<WheelEvent, "clientX" | "clientY" | "ctrlKey" | "deltaY" | "metaKey" | "preventDefault" | "target">,
  editorState: TemplateEditorCanvasZoomState,
  options?: Omit<TemplateEditorCanvasZoomOptions, "editorState" | "focalPoint" | "mode" | "zoom">,
): boolean;

export function normalizeObjectSizeInputValue(value?: unknown): number | null;
export function parseObjectSizePixelValue(value?: unknown, fallback?: number): number;
export function parseObjectSizeInlinePixelValue(value?: unknown, fallback?: number): number;
export function getCandidateBlockModalContentSize(
  modalSurfaceElement?: HTMLElement | null,
): { height: number; width: number } | null;
export function getCandidateBlockGridMinimumSize(
  gridElement?: HTMLElement | null,
  options?: {
    getTableMinimumSize?: ((gridElement?: HTMLElement | null) => { height?: number; width?: number }) | null;
  },
): { height: number; width: number };
export function getObjectTableCollapsedBorderAdjustment(tableElement?: HTMLTableElement | null): number;
export function getObjectTableRenderedTargetWidth(tableElement: HTMLTableElement | null, targetWidth: number): number;
export function getObjectTableColumnWidths(
  tableElement: HTMLTableElement,
  columns: HTMLElement[],
  cellMap: unknown,
  tableUtils?: {
    getTemplateEditorMeasuredColumnWidth?: (cellMap: unknown, columnIndex: number) => number;
  },
): number[];
export function getObjectTableRowHeights(tableElement?: HTMLTableElement | null): number[];

export interface ObjectAlignmentCanvasMetrics {
  height: number;
  rect: DOMRect;
  scaleX: number;
  scaleY: number;
  width: number;
}

export function parseObjectAlignmentPixelValue(value?: unknown, fallback?: number): number;
export function roundObjectAlignmentValue(value?: unknown): number;
export function clampObjectAlignmentValue(value: unknown, maximum: unknown): number;
export function getObjectAlignmentDocumentElement(surfaceElement?: HTMLElement | null): HTMLElement | null;
export function getObjectAlignmentPositioningElement(
  element?: Element | null,
  surfaceElement?: HTMLElement | null,
): HTMLElement | null;
export function getObjectAlignmentOverlayContainer(
  element?: Element | null,
  surfaceElement?: HTMLElement | null,
): HTMLElement | null;
export function isObjectEditorReadOnly(surfaceElement?: HTMLElement | null): boolean;
export function getObjectCandidateBlockModalElement(
  element?: Element | null,
  surfaceElement?: HTMLElement | null,
): HTMLElement | null;
export function getObjectCandidateBlockVisualScale(element?: Element | null): { x: number; y: number };
export function getObjectAlignmentCanvasMetrics(documentElement: HTMLElement): ObjectAlignmentCanvasMetrics;
export function getObjectAlignmentImageElements(surfaceElement?: HTMLElement | null): HTMLImageElement[];
export function isObjectAlignmentTableElement(
  element?: Element | null,
  surfaceElement?: HTMLElement | null,
): boolean;
export function getObjectAlignmentTableElements(surfaceElement?: HTMLElement | null): HTMLTableElement[];
export function isObjectAlignmentElement(element?: Element | null, surfaceElement?: HTMLElement | null): boolean;
export function getObjectAlignmentElements(surfaceElement?: HTMLElement | null): HTMLElement[];
export function getSelectedObjectAlignmentElements(surfaceElement?: HTMLElement | null): HTMLElement[];
export function getObjectAlignmentEventTarget(
  target?: EventTarget | Node | null,
  surfaceElement?: HTMLElement | null,
  event?: Pick<PointerEvent, "clientX" | "clientY"> | null,
): HTMLElement | null;
export function getObjectTableCellElement(
  element?: Element | null,
  surfaceElement?: HTMLElement | null,
): HTMLElement | null;
export function getObjectTableCellContentSize(
  element?: Element | null,
  surfaceElement?: HTMLElement | null,
  minimumSize?: number,
): { height: number; width: number } | null;
export function getObjectElementSize(
  element?: HTMLElement | null,
  surfaceElement?: HTMLElement | null,
): { height: number; width: number };
export function syncObjectAlignmentTableFlow(
  element?: HTMLElement | null,
  surfaceElement?: HTMLElement | null,
  geometry?: {
    height?: number;
    movementY?: number;
    reorderByPosition?: boolean;
    top?: number;
  },
  adapters?: {
    reflowTemplateEditorObjectRows?: (element: HTMLElement, options: Record<string, unknown>) => unknown;
  },
): unknown;
