import "../extensions/examlist/shared/document-html-sanitizer.js";
import { normalizeDocumentTokenNodes } from "./document-editor-tokens.js";

export function sanitizeNodeTree(root) {
  if (root?.childNodes) globalThis.ExamListDocumentHtmlSanitizer.sanitizeNodeTree(root);
}
export function normalizeDocumentFontNodes(root) {
  globalThis.ExamListDocumentHtmlSanitizer.normalizeDocumentFontNodes(root);
}
export function stripTransientDocumentState(root) {
  globalThis.ExamListDocumentHtmlSanitizer.stripTransientDocumentState(root);
}
export function sanitizeTemplateEditorHtml(value, documentRef = globalThis.document) {
  if (!documentRef?.createElement) throw new Error("sanitizeTemplateEditorHtml() requires a browser Document.");
  const template = documentRef.createElement("template");
  template.innerHTML = String(value || "");
  stripTransientDocumentState(template.content);
  sanitizeNodeTree(template.content);
  normalizeDocumentFontNodes(template.content);
  normalizeDocumentTokenNodes(template.content, { document: documentRef, preservePresentation: true });
  return template.innerHTML;
}
